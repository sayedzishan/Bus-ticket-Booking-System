Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Data.SqlClient
Public Class CompanyInfoDAL
	Private SqlCon As SqlConnection = BaseDAL.Connection_through_Config()
	Public Sub New()
	End Sub
	Public Function InsertCompanyInfo(ObjCompanyInfoBO As CompanyInfoBO) As Integer
		SqlCon.Open()
		Dim Inscommand As New SqlCommand("sp_tblCompanyInfo", SqlCon)
		Inscommand.CommandType = CommandType.StoredProcedure
		Inscommand.Parameters.AddWithValue("@Type", "I")
		Inscommand.Parameters.AddWithValue("@CompanyName", ObjCompanyInfoBO.CompanyName)
		Inscommand.Parameters.AddWithValue("@Description", ObjCompanyInfoBO.Description)
		Inscommand.Parameters.AddWithValue("@Address", ObjCompanyInfoBO.Address)
		Inscommand.Parameters.AddWithValue("@CompanyLogo", ObjCompanyInfoBO.CompanyLogo)
		Try
			Return Inscommand.ExecuteNonQuery()
		Catch
			Throw
		Finally
			Inscommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function UpdatetblCompanyInfo(ObjCompanyInfoBO As CompanyInfoBO) As Integer
		SqlCon.Open()
		Dim Upscommand As New SqlCommand("sp_tblCompanyInfo", SqlCon)
		Upscommand.CommandType = CommandType.StoredProcedure
		Upscommand.Parameters.AddWithValue("@Type", "U")
		Upscommand.Parameters.AddWithValue("@CompanyID", ObjCompanyInfoBO.CompanyID)
		Upscommand.Parameters.AddWithValue("@CompanyName", ObjCompanyInfoBO.CompanyName)
		Upscommand.Parameters.AddWithValue("@Description", ObjCompanyInfoBO.Description)
		Upscommand.Parameters.AddWithValue("@Address", ObjCompanyInfoBO.Address)
		Upscommand.Parameters.AddWithValue("@CompanyLogo", ObjCompanyInfoBO.CompanyLogo)
		Try
			Return Upscommand.ExecuteNonQuery()
		Catch
			Throw
		Finally
			Upscommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function EditCompanyDetails(ObjCompanyInfoBO As CompanyInfoBO) As DataSet
		SqlCon.Open()
		Dim ShowCommand As New SqlCommand("sp_tblCompanyInfo", SqlCon)
		ShowCommand.CommandType = CommandType.StoredProcedure
		ShowCommand.Parameters.AddWithValue("@Type", "T")
		ShowCommand.Parameters.AddWithValue("@CompanyID", ObjCompanyInfoBO.CompanyID)
		Dim DataAdapter As New SqlDataAdapter(ShowCommand)
		Dim ds As New DataSet()
		Try
			DataAdapter.Fill(ds, "tblCompanyInfo")
			Return ds
		Catch
			Throw
		Finally
			ShowCommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function GetDataOrderByDate(ObjCompanyInfoBO As CompanyInfoBO) As DataSet
		Try
			Dim DaGetDataOrderByDate As New SqlDataAdapter("sp_tblCompanyInfo", SqlCon)
			DaGetDataOrderByDate.SelectCommand.CommandType = CommandType.StoredProcedure
			DaGetDataOrderByDate.SelectCommand.Parameters.AddWithValue("@Type", "S")
			Dim DsGetDataOrderByDate As New DataSet()
			DaGetDataOrderByDate.Fill(DsGetDataOrderByDate)
			Return DsGetDataOrderByDate
		Catch
			Return Nothing
		End Try
	End Function
End Class
