Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Data.SqlClient
Public Class MailaFriendDAL
	Private SqlCon As SqlConnection = BaseDAL.Connection_through_Config()
	Public Sub New()
	End Sub
	Public Function InserttblMailaFriend(ObjMailaFriendBO As MailaFriendBO) As Integer
		SqlCon.Open()
		Dim Inscommand As New SqlCommand("sp_tblMailaFriend", SqlCon)
		Inscommand.CommandType = CommandType.StoredProcedure
		Inscommand.Parameters.AddWithValue("@Type", "I")
		Inscommand.Parameters.AddWithValue("@YourEmailID", ObjMailaFriendBO.YourEmailID)
		Inscommand.Parameters.AddWithValue("@FriendsEmailID1", ObjMailaFriendBO.FriendsEmailID1)
		Inscommand.Parameters.AddWithValue("@EmailID2", ObjMailaFriendBO.EmailID2)
		Inscommand.Parameters.AddWithValue("@EmailID3", ObjMailaFriendBO.EmailID3)
		Inscommand.Parameters.AddWithValue("@EmailID4", ObjMailaFriendBO.EmailID4)
		Inscommand.Parameters.AddWithValue("@EmailID5", ObjMailaFriendBO.EmailID5)
		Inscommand.Parameters.AddWithValue("@StandardContent", ObjMailaFriendBO.StandardContent)
		Inscommand.Parameters.AddWithValue("@Comments", ObjMailaFriendBO.Comments)
		Try
			Return Inscommand.ExecuteNonQuery()
		Catch
			Throw
		Finally
			Inscommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function getEmailId(ObjMailaFriendBO As MailaFriendBO) As DataSet
		SqlCon.Open()
		Dim ShowCommand As New SqlCommand("sp_tblMailaFriend", SqlCon)
		ShowCommand.CommandType = CommandType.StoredProcedure
		ShowCommand.Parameters.AddWithValue("@Type", "S")
		ShowCommand.Parameters.AddWithValue("@ID", ObjMailaFriendBO.ID)
		Dim DataAdapter As New SqlDataAdapter(ShowCommand)
		Dim ds As New DataSet()
		Try
			DataAdapter.Fill(ds, "tblMailaFriend")
			Return ds
		Catch
			Throw
		Finally
			ShowCommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
End Class
