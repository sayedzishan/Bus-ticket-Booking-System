Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Data.SqlClient
Public Class BaseDAL
	Public Sub New()
	End Sub
	Public Shared Function Connection_through_Config() As SqlConnection
		Dim ConString As String
		ConString = ConfigurationManager.AppSettings("ConStr")
		Dim SqlCon As New SqlConnection(ConString)
		Return SqlCon
	End Function
End Class
