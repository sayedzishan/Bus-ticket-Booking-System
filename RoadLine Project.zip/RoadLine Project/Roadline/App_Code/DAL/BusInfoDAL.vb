Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Data.SqlClient
Public Class BusInfoDAL
	Private SqlCon As SqlConnection = BaseDAL.Connection_through_Config()
	Public Sub New()
	End Sub
	Public Function InsertIntoBusInfo(ObjBusInfoBO As BusInfoBO) As Integer
		SqlCon.Open()
		Dim Inscommand As New SqlCommand("sp_tblBusInfo", SqlCon)
		Inscommand.CommandType = CommandType.StoredProcedure
		Inscommand.Parameters.AddWithValue("@Type", "I")
		Inscommand.Parameters.AddWithValue("@ServiceName", ObjBusInfoBO.ServiceName)
		Inscommand.Parameters.AddWithValue("@ServiceNumber", ObjBusInfoBO.ServiceNumber)
		Inscommand.Parameters.AddWithValue("@TravelName", ObjBusInfoBO.TravelName)
		Inscommand.Parameters.AddWithValue("@BusType", ObjBusInfoBO.BusType)
		Inscommand.Parameters.AddWithValue("@Source", ObjBusInfoBO.Source)
		Inscommand.Parameters.AddWithValue("@Destination", ObjBusInfoBO.Destination)
		Inscommand.Parameters.AddWithValue("@StartTime", ObjBusInfoBO.StartTime)
		Inscommand.Parameters.AddWithValue("@ReachTime", ObjBusInfoBO.ReachTime)
		Inscommand.Parameters.AddWithValue("@Fare", ObjBusInfoBO.Fare)
		Inscommand.Parameters.AddWithValue("@DateOfJourney", ObjBusInfoBO.DateOfJourney)
		Inscommand.Parameters.AddWithValue("@NoOfSeatsAvailable", ObjBusInfoBO.NoOfSeatsAvailable)
		Try
			Return Inscommand.ExecuteNonQuery()
		Catch
			Throw
		Finally
			Inscommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function UpdatetblBusInfo(ObjBusInfoBO As BusInfoBO) As Integer
		SqlCon.Open()
		Dim Upscommand As New SqlCommand("sp_tblBusInfo", SqlCon)
		Upscommand.CommandType = CommandType.StoredProcedure
		Upscommand.Parameters.AddWithValue("@Type", "U")
		Upscommand.Parameters.AddWithValue("@ServiceID", ObjBusInfoBO.ServiceID)
		Upscommand.Parameters.AddWithValue("@ServiceName", ObjBusInfoBO.ServiceName)
		Upscommand.Parameters.AddWithValue("@ServiceNumber", ObjBusInfoBO.ServiceNumber)
		Upscommand.Parameters.AddWithValue("@TravelName", ObjBusInfoBO.TravelName)
		Upscommand.Parameters.AddWithValue("@BusType", ObjBusInfoBO.BusType)
		Upscommand.Parameters.AddWithValue("@Source", ObjBusInfoBO.Source)
		Upscommand.Parameters.AddWithValue("@Destination", ObjBusInfoBO.Destination)
		Upscommand.Parameters.AddWithValue("@StartTime", ObjBusInfoBO.StartTime)
		Upscommand.Parameters.AddWithValue("@ReachTime", ObjBusInfoBO.ReachTime)
		Upscommand.Parameters.AddWithValue("@Fare", ObjBusInfoBO.Fare)
		Upscommand.Parameters.AddWithValue("@DateOfJourney", ObjBusInfoBO.DateOfJourney)
		Upscommand.Parameters.AddWithValue("@NoOfSeatsAvailable", ObjBusInfoBO.NoOfSeatsAvailable)
		Try
			Return Upscommand.ExecuteNonQuery()
		Catch
			Throw
		Finally
			Upscommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function ShowBusDetails(ObjBusInfoBO As BusInfoBO) As DataSet
		SqlCon.Open()
		Dim ShowCommand As New SqlCommand("sp_tblBusInfo", SqlCon)
		ShowCommand.CommandType = CommandType.StoredProcedure
		ShowCommand.Parameters.AddWithValue("@Type", "S")
		Dim DataAdapter As New SqlDataAdapter(ShowCommand)
		Dim ds As New DataSet()
		Try
			DataAdapter.Fill(ds, "tblBusInfo")
			Return ds
		Catch
			Throw
		Finally
			ShowCommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function EditBusDetails(ObjBusInfoBO As BusInfoBO) As DataSet
		SqlCon.Open()
		Dim ShowCommand As New SqlCommand("sp_tblBusInfo", SqlCon)
		ShowCommand.CommandType = CommandType.StoredProcedure
		ShowCommand.Parameters.AddWithValue("@Type", "T")
		ShowCommand.Parameters.AddWithValue("@ServiceID", ObjBusInfoBO.ServiceID)
		Dim DataAdapter As New SqlDataAdapter(ShowCommand)
		Dim ds As New DataSet()
		Try
			DataAdapter.Fill(ds, "tblBusInfo")
			Return ds
		Catch
			Throw
		Finally
			ShowCommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function DeleteFromtblBusInfo(StrIds As [String]) As [Boolean]
		Try
			SqlCon.Open()
			Dim DeleteCommand As New SqlCommand("sp_tblBusInfo", SqlCon)
			DeleteCommand.CommandType = CommandType.StoredProcedure
			DeleteCommand.Parameters.AddWithValue("@Type", "D")
			DeleteCommand.Parameters.AddWithValue("@StrIds", StrIds)
			DeleteCommand.ExecuteNonQuery()
			Return True
		Catch
			Return False
		Finally
			SqlCon.Close()
		End Try
	End Function
	Public Function SearchDetails(SearchString As String) As DataSet
		SqlCon.Open()
		Dim ShowCommand As New SqlCommand("sp_tblBusInfo", SqlCon)
		ShowCommand.CommandType = CommandType.StoredProcedure
		ShowCommand.Parameters.AddWithValue("@Type", "Z")
		ShowCommand.Parameters.AddWithValue("@SearchString", SearchString)
		Dim DataAdapter As New SqlDataAdapter(ShowCommand)
		Dim ds As New DataSet()
		Try
			DataAdapter.Fill(ds, "tblBusInfo")
			Return ds
		Catch
			Throw
		Finally
			ShowCommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
End Class
