Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Data.SqlClient
Public Class FeedbackDAL
	Private SqlCon As SqlConnection = BaseDAL.Connection_through_Config()
	Public Sub New()
	End Sub
	Public Function InsertFeedback(ObjFeedbackBO As FeedbackBO) As Integer
		SqlCon.Open()
		Dim Inscommand As New SqlCommand("sp_tblFeedback", SqlCon)
		Inscommand.CommandType = CommandType.StoredProcedure
		Inscommand.Parameters.AddWithValue("@Type", "I")
		Inscommand.Parameters.AddWithValue("@UserName", ObjFeedbackBO.UserName)
		Inscommand.Parameters.AddWithValue("@Email", ObjFeedbackBO.Email)
		Inscommand.Parameters.AddWithValue("@Mobile", ObjFeedbackBO.Mobile)
		Inscommand.Parameters.AddWithValue("@Phone", ObjFeedbackBO.Phone)
		Inscommand.Parameters.AddWithValue("@Subject", ObjFeedbackBO.Subject)
		Inscommand.Parameters.AddWithValue("@Comments", ObjFeedbackBO.Comments)
		Inscommand.Parameters.AddWithValue("@RatingOfSite", ObjFeedbackBO.RatingOfSite)
		Try
			Return Inscommand.ExecuteNonQuery()
		Catch
			Throw
		Finally
			Inscommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function ShowFeedbackFromtblFeedback(ObjFeedbackBO As FeedbackBO) As DataSet
		SqlCon.Open()
		Dim ShowCommand As New SqlCommand("sp_tblFeedback", SqlCon)
		ShowCommand.CommandType = CommandType.StoredProcedure
		ShowCommand.Parameters.AddWithValue("@Type", "S")
		Dim DataAdapter As New SqlDataAdapter(ShowCommand)
		Dim ds As New DataSet()
		Try
			DataAdapter.Fill(ds, "tblFeedback")
			Return ds
		Catch
			Throw
		Finally
			ShowCommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function DeleteFromtblFeedback(StrIds As [String]) As [Boolean]
		Try
			SqlCon.Open()
			Dim DeleteCommand As New SqlCommand("sp_tblFeedback", SqlCon)
			DeleteCommand.CommandType = CommandType.StoredProcedure
			DeleteCommand.Parameters.AddWithValue("@Type", "D")
			DeleteCommand.Parameters.AddWithValue("@StrIds", StrIds)
			DeleteCommand.ExecuteNonQuery()
			Return True
		Catch
			Return False
		Finally
			SqlCon.Close()
		End Try
	End Function
	Public Function ShowFeedbackDetailsFromtblFeedback(ObjFeedbackBO As FeedbackBO) As DataSet
		SqlCon.Open()
		Dim ShowCommand As New SqlCommand("sp_tblFeedback", SqlCon)
		ShowCommand.CommandType = CommandType.StoredProcedure
		ShowCommand.Parameters.AddWithValue("@Type", "T")
		ShowCommand.Parameters.AddWithValue("@FeedbackID", ObjFeedbackBO.FeedbackID)
		Dim DataAdapter As New SqlDataAdapter(ShowCommand)
		Dim ds As New DataSet()
		Try
			DataAdapter.Fill(ds, "tblFeedback")
			Return ds
		Catch
			Throw
		Finally
			ShowCommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Sub Dispose()
		SqlCon.Close()
	End Sub
End Class
