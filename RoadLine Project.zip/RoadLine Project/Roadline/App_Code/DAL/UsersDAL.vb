Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Data.SqlClient
Public Class UsersDAL
	Private SqlCon As SqlConnection = BaseDAL.Connection_through_Config()
	Public Sub New()
	End Sub
	Public Function CheckAvailability(objUsersBO As UsersBO) As DataSet
		Try
			Dim DaCheckAvail As New SqlDataAdapter("sp_tblUsers", SqlCon)
			DaCheckAvail.SelectCommand.CommandType = CommandType.StoredProcedure
			DaCheckAvail.SelectCommand.Parameters.AddWithValue("@Type", "L")
			DaCheckAvail.SelectCommand.Parameters.AddWithValue("@UserName", objUsersBO.UserName)
			Dim DsCheckAvail As New DataSet()
			DaCheckAvail.Fill(DsCheckAvail)
			Return DsCheckAvail
		Catch
			Return Nothing
		End Try
	End Function
	Public Function InsertIntotblUsers(ObjUsersBO As UsersBO) As Int64
		Dim intUserId As Int64 = 0
		Try
			SqlCon.Open()
			Dim InsertCmd As New SqlCommand("sp_tblUsers", SqlCon)
			InsertCmd.CommandType = CommandType.StoredProcedure
			Dim ParamUserId As SqlParameter = InsertCmd.Parameters.Add("@UserID", SqlDbType.BigInt, 8)
			ParamUserId.Direction = ParameterDirection.Output
			InsertCmd.Parameters.AddWithValue("@UserName", ObjUsersBO.UserName)
			InsertCmd.Parameters.AddWithValue("@Password", ObjUsersBO.Password)
			InsertCmd.Parameters.AddWithValue("@Email", ObjUsersBO.Email)
			InsertCmd.Parameters.AddWithValue("@Mobile", ObjUsersBO.Mobile)
			InsertCmd.Parameters.AddWithValue("@Phone", ObjUsersBO.Phone)
			InsertCmd.Parameters.AddWithValue("@Country", ObjUsersBO.Country)
			InsertCmd.Parameters.AddWithValue("@City", ObjUsersBO.City)
			InsertCmd.Parameters.AddWithValue("@Address", ObjUsersBO.Address)
			InsertCmd.Parameters.AddWithValue("@Type", "I"C)
			InsertCmd.ExecuteNonQuery()
			intUserId = Convert.ToInt64(ParamUserId.Value.ToString())
			Return intUserId
		Catch
			Throw
		Finally
			SqlCon.Close()
		End Try
	End Function
	Public Function ShowUsersInfo(ObjUsersBO As UsersBO) As DataSet
		SqlCon.Open()
		Dim ShowCommand As New SqlCommand("sp_tblUsers", SqlCon)
		ShowCommand.CommandType = CommandType.StoredProcedure
		ShowCommand.Parameters.AddWithValue("@Type", "R")
		ShowCommand.Parameters.AddWithValue("@UserID", ObjUsersBO.UserID)
		Dim DataAdapter As New SqlDataAdapter(ShowCommand)
		Dim ds As New DataSet()
		Try
			DataAdapter.Fill(ds, "tblUsers")
			Return ds
		Catch
			Throw
		Finally
			ShowCommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function ShowUsersInfo1(ObjUsersBO As UsersBO) As DataSet
		SqlCon.Open()
		Dim ShowCommand As New SqlCommand("sp_tblUsers", SqlCon)
		ShowCommand.CommandType = CommandType.StoredProcedure
		ShowCommand.Parameters.AddWithValue("@Type", "B")
		Dim DataAdapter As New SqlDataAdapter(ShowCommand)
		Dim ds As New DataSet()
		Try
			DataAdapter.Fill(ds, "tblUsers")
			Return ds
		Catch
			Throw
		Finally
			ShowCommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function UpdatetblUsers(ObjUsersBO As UsersBO) As Integer
		SqlCon.Open()
		Dim Upscommand As New SqlCommand("sp_tblUsers", SqlCon)
		Upscommand.CommandType = CommandType.StoredProcedure
		Upscommand.Parameters.AddWithValue("@Type", "U")
		Upscommand.Parameters.AddWithValue("@UserId", ObjUsersBO.UserID)
		Upscommand.Parameters.AddWithValue("@Email", ObjUsersBO.Email)
		Upscommand.Parameters.AddWithValue("@Address", ObjUsersBO.Address)
		Upscommand.Parameters.AddWithValue("@Country", ObjUsersBO.Country)
		Upscommand.Parameters.AddWithValue("@Phone", ObjUsersBO.Phone)
		Upscommand.Parameters.AddWithValue("@City", ObjUsersBO.City)
		Upscommand.Parameters.AddWithValue("@Mobile", ObjUsersBO.Mobile)
		Try
			Return Upscommand.ExecuteNonQuery()
		Catch
			Throw
		Finally
			Upscommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function ChangePassword(usersBO As UsersBO) As Integer
		SqlCon.Open()
		Dim SqlCmd As New SqlCommand("sp_tblUsers", SqlCon)
		SqlCmd.CommandType = CommandType.StoredProcedure
		SqlCmd.Parameters.AddWithValue("@UserID", usersBO.UserID)
		SqlCmd.Parameters.AddWithValue("@Password", usersBO.Password)
		SqlCmd.Parameters.AddWithValue("@Type", "C")
		Try
			Return SqlCmd.ExecuteNonQuery()
		Catch
			Return 0
		Finally
			SqlCmd.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function ShowUsers(ObjUsersBO As UsersBO) As DataSet
		SqlCon.Open()
		Dim SqlCmd As New SqlCommand("sp_tblUsers", SqlCon)
		SqlCmd.CommandType = CommandType.StoredProcedure
		SqlCmd.Parameters.AddWithValue("@UserID", ObjUsersBO.UserID)
		SqlCmd.Parameters.AddWithValue("@Type", "R")
		Dim SqlDA As New SqlDataAdapter(SqlCmd)
		Dim ds As New DataSet()
		Try
			SqlDA.Fill(ds, "tblUsers")
			Return ds
		Catch
			Throw
		Finally
			SqlCon.Close()
			SqlCmd.Dispose()
		End Try
	End Function
	Public Function EditUserDetails(ObjUsersBO As UsersBO) As DataSet
		SqlCon.Open()
		Dim ShowCommand As New SqlCommand("sp_tblUsers", SqlCon)
		ShowCommand.CommandType = CommandType.StoredProcedure
		ShowCommand.Parameters.AddWithValue("@Type", "S")
		ShowCommand.Parameters.AddWithValue("@UserID", ObjUsersBO.UserID)
		Dim DataAdapter As New SqlDataAdapter(ShowCommand)
		Dim ds As New DataSet()
		Try
			DataAdapter.Fill(ds, "tblUsers")
			Return ds
		Catch
			Throw
		Finally
			ShowCommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function DeleteFromtblUsers(StrIds As [String]) As [Boolean]
		Try
			SqlCon.Open()
			Dim DeleteCommand As New SqlCommand("sp_tblUsers", SqlCon)
			DeleteCommand.CommandType = CommandType.StoredProcedure
			DeleteCommand.Parameters.AddWithValue("@Type", "D")
			DeleteCommand.Parameters.AddWithValue("@StrIds", StrIds)
			DeleteCommand.ExecuteNonQuery()
			Return True
		Catch
			Return False
		Finally
			SqlCon.Close()
		End Try
	End Function
	Public Function UpdateUserStatus(ObjUsersBO As UsersBO) As Integer
		Try
			SqlCon.Open()
			Dim SqlCmd As New SqlCommand("sp_tblUsers", SqlCon)
			SqlCmd.CommandType = CommandType.StoredProcedure
			SqlCmd.Parameters.AddWithValue("@Type", "F")
			SqlCmd.Parameters.AddWithValue("@Status", ObjUsersBO.Status)
			SqlCmd.Parameters.AddWithValue("@UserID", ObjUsersBO.UserID)
			Return SqlCmd.ExecuteNonQuery()
		Catch
			Return 0
		Finally
			SqlCon.Close()
		End Try
	End Function
	Public Function CheckLogin(usersBO As UsersBO) As DataSet
		SqlCon.Open()
		Dim SqlCmd As New SqlCommand("sp_tblUsers", SqlCon)
		SqlCmd.CommandType = CommandType.StoredProcedure
		SqlCmd.Parameters.AddWithValue("@UserName", usersBO.UserName)
		SqlCmd.Parameters.AddWithValue("@Password", usersBO.Password)
		SqlCmd.Parameters.AddWithValue("@Type", "L")
		Dim SqlDA As New SqlDataAdapter(SqlCmd)
		Dim ds As New DataSet()
		Try
			SqlDA.Fill(ds, "tblUsers")
			Return ds
		Catch
			Throw
		Finally
			SqlCon.Close()
			SqlCmd.Dispose()
		End Try
	End Function
	Public Function ForgotPasswordforEamil(Email As String) As DataSet
		SqlCon.Open()
		Dim SqlCmd As New SqlCommand("sp_tblUsers", SqlCon)
		SqlCmd.CommandType = CommandType.StoredProcedure
		SqlCmd.Parameters.AddWithValue("@Email", Email)
		SqlCmd.Parameters.AddWithValue("@Type", "X")
		Dim SqlDA As New SqlDataAdapter(SqlCmd)
		Dim ds As New DataSet()
		Try
			SqlDA.Fill(ds, "tblUsers")
			Return ds
		Catch
			Return Nothing
		Finally
			SqlCon.Close()
			SqlCmd.Dispose()
		End Try
	End Function
	Public Function ForgotPassword(usersBO As UsersBO) As DataSet
		SqlCon.Open()
		Dim SqlCmd As New SqlCommand("sp_tblUsers", SqlCon)
		SqlCmd.CommandType = CommandType.StoredProcedure
		SqlCmd.Parameters.AddWithValue("@UserName", usersBO.UserName)
		SqlCmd.Parameters.AddWithValue("@Type", "L")
		Dim SqlDA As New SqlDataAdapter(SqlCmd)
		Dim ds As New DataSet()
		Try
			SqlDA.Fill(ds, "tblUsers")
			Return ds
		Catch
			Return Nothing
		Finally
			SqlCon.Close()
			SqlCmd.Dispose()
		End Try
	End Function
	Public Function Login(usersBO As UsersBO, check As String) As DataSet
		Try
			Dim DaGetData As New SqlDataAdapter("sp_tblUsers", SqlCon)
			DaGetData.SelectCommand.CommandType = CommandType.StoredProcedure
			DaGetData.SelectCommand.Parameters.AddWithValue("@check", check)
			DaGetData.SelectCommand.Parameters.AddWithValue("@Username", usersBO.UserName)
			DaGetData.SelectCommand.Parameters.AddWithValue("@Password", usersBO.Password)
			DaGetData.SelectCommand.Parameters.AddWithValue("@Type", "Z")
			Dim DsGetData As New DataSet()
			DaGetData.Fill(DsGetData)
			Return DsGetData
		Catch
			Return Nothing
		End Try
	End Function
End Class
