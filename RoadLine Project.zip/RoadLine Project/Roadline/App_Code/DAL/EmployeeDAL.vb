Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Data.SqlClient
Public Class EmployeeDAL
	Private SqlCon As SqlConnection = BaseDAL.Connection_through_Config()
	Public Sub New()
	End Sub
	Public Function InsertEmployeeInfo(ObjEmployeeBO As EmployeeBO) As Integer
		SqlCon.Open()
		Dim Inscommand As New SqlCommand("sp_tblEmployees", SqlCon)
		Inscommand.CommandType = CommandType.StoredProcedure
		Inscommand.Parameters.AddWithValue("@Type", "I")
		Inscommand.Parameters.AddWithValue("@EmployeeName", ObjEmployeeBO.EmployeeName)
		Inscommand.Parameters.AddWithValue("@Designation", ObjEmployeeBO.Designation)
		Inscommand.Parameters.AddWithValue("@Email", ObjEmployeeBO.Email)
		Inscommand.Parameters.AddWithValue("@Address", ObjEmployeeBO.Address)
		Inscommand.Parameters.AddWithValue("@Mobile", ObjEmployeeBO.Mobile)
		Inscommand.Parameters.AddWithValue("@AllotedToBranch", ObjEmployeeBO.AllotedToBranch)
		Try
			Return Inscommand.ExecuteNonQuery()
		Catch
			Throw
		Finally
			Inscommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function UpdatetblEmployees(ObjEmployeeBO As EmployeeBO) As Integer
		SqlCon.Open()
		Dim Upscommand As New SqlCommand("sp_tblEmployees", SqlCon)
		Upscommand.CommandType = CommandType.StoredProcedure
		Upscommand.Parameters.AddWithValue("@Type", "U")
		Upscommand.Parameters.AddWithValue("@EmployeeID", ObjEmployeeBO.EmployeeID)
		Upscommand.Parameters.AddWithValue("@Email", ObjEmployeeBO.Email)
		Upscommand.Parameters.AddWithValue("@Address", ObjEmployeeBO.Address)
		Upscommand.Parameters.AddWithValue("@EmployeeName", ObjEmployeeBO.EmployeeName)
		Upscommand.Parameters.AddWithValue("@Designation", ObjEmployeeBO.Designation)
		Upscommand.Parameters.AddWithValue("@AllotedToBranch", ObjEmployeeBO.AllotedToBranch)
		Upscommand.Parameters.AddWithValue("@Mobile", ObjEmployeeBO.Mobile)
		Try
			Return Upscommand.ExecuteNonQuery()
		Catch
			Throw
		Finally
			Upscommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function ShowEmployeeDetails(ObjEmployeeBO As EmployeeBO) As DataSet
		SqlCon.Open()
		Dim ShowCommand As New SqlCommand("sp_tblEmployees", SqlCon)
		ShowCommand.CommandType = CommandType.StoredProcedure
		ShowCommand.Parameters.AddWithValue("@Type", "T")
		ShowCommand.Parameters.AddWithValue("@EmployeeID", ObjEmployeeBO.EmployeeID)
		Dim DataAdapter As New SqlDataAdapter(ShowCommand)
		Dim ds As New DataSet()
		Try
			DataAdapter.Fill(ds, "tblEmployees")
			Return ds
		Catch
			Throw
		Finally
			ShowCommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function ShowEmployee(ObjEmployeeBO As EmployeeBO) As DataSet
		SqlCon.Open()
		Dim ShowCommand As New SqlCommand("sp_tblEmployees", SqlCon)
		ShowCommand.CommandType = CommandType.StoredProcedure
		ShowCommand.Parameters.AddWithValue("@Type", "S")
		Dim DataAdapter As New SqlDataAdapter(ShowCommand)
		Dim ds As New DataSet()
		Try
			DataAdapter.Fill(ds, "tblEmployees")
			Return ds
		Catch
			Throw
		Finally
			ShowCommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function DeleteFromtblEmployees(StrIds As [String]) As [Boolean]
		Try
			SqlCon.Open()
			Dim DeleteCommand As New SqlCommand("sp_tblEmployees", SqlCon)
			DeleteCommand.CommandType = CommandType.StoredProcedure
			DeleteCommand.Parameters.AddWithValue("@Type", "D")
			DeleteCommand.Parameters.AddWithValue("@StrIds", StrIds)
			DeleteCommand.ExecuteNonQuery()
			Return True
		Catch
			Return False
		Finally
			SqlCon.Close()
		End Try
	End Function
End Class
