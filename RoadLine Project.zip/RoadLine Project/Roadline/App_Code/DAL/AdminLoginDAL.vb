Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Data.SqlClient
Public Class AdminLoginDAL
	Private SqlCon As SqlConnection = BaseDAL.Connection_through_Config()
	Public Sub New()
	End Sub
End Class
