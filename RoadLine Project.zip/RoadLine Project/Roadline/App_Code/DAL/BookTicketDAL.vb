Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Data.SqlClient
Public Class BookTicketDAL
	Private SqlCon As SqlConnection = BaseDAL.Connection_through_Config()
	Public Sub New()
	End Sub
	Public Function GetServiceNumbers(ObjBookTicketBO As BookTicketBO) As DataSet
		SqlCon.Open()
		Dim ShowCommand As New SqlCommand("sp_tblBusInfo", SqlCon)
		ShowCommand.CommandType = CommandType.StoredProcedure
		ShowCommand.Parameters.AddWithValue("@Type", "S")
		Dim DataAdapter As New SqlDataAdapter(ShowCommand)
		Dim ds As New DataSet()
		Try
			DataAdapter.Fill(ds, "tblBusInfo")
			Return ds
		Catch
			Throw
		Finally
			ShowCommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function Record(ObjBookTicketBO As BookTicketBO) As DataSet
		SqlCon.Open()
		Dim ShowCommand As New SqlCommand("sp_tblBusInfo", SqlCon)
		ShowCommand.CommandType = CommandType.StoredProcedure
		ShowCommand.Parameters.AddWithValue("@Type", "R")
		ShowCommand.Parameters.AddWithValue("@ServiceNumber", ObjBookTicketBO.ServiceNumber)
		Dim DataAdapter As New SqlDataAdapter(ShowCommand)
		Dim ds As New DataSet()
		Try
			DataAdapter.Fill(ds, "tblBusInfo")
			Return ds
		Catch
			Throw
		Finally
			ShowCommand.Dispose()
			SqlCon.Close()
		End Try
	End Function
	Public Function InsertIntotblBookTicket(ObjBookTicketBO As BookTicketBO) As Int64
		Dim intUserId As Int64 = 0
		Try
			SqlCon.Open()
			Dim InsertCmd As New SqlCommand("sp_tblBookTicket", SqlCon)
			InsertCmd.CommandType = CommandType.StoredProcedure
			Dim ParamUserId As SqlParameter = InsertCmd.Parameters.Add("@TicketID", SqlDbType.BigInt, 8)
			ParamUserId.Direction = ParameterDirection.Output
			InsertCmd.Parameters.AddWithValue("@FullName", ObjBookTicketBO.FullName)
			InsertCmd.Parameters.AddWithValue("@PaymentMode", ObjBookTicketBO.PaymentMode)
			InsertCmd.Parameters.AddWithValue("@Mobile", ObjBookTicketBO.Mobile)
			InsertCmd.Parameters.AddWithValue("@Gender", ObjBookTicketBO.Gender)
			InsertCmd.Parameters.AddWithValue("@Email", ObjBookTicketBO.Email)
			InsertCmd.Parameters.AddWithValue("@Address", ObjBookTicketBO.Address)
			InsertCmd.Parameters.AddWithValue("@IDCardType", ObjBookTicketBO.IDCardType)
			InsertCmd.Parameters.AddWithValue("@IDCardNumber", ObjBookTicketBO.IDCardNumber)
			InsertCmd.Parameters.AddWithValue("@IssuingAuthority", ObjBookTicketBO.IssuingAuthority)
			InsertCmd.Parameters.AddWithValue("@Source", ObjBookTicketBO.Source)
			InsertCmd.Parameters.AddWithValue("@Destination", ObjBookTicketBO.Destination)
			InsertCmd.Parameters.AddWithValue("@SeatNumber", ObjBookTicketBO.SeatNumber)
			InsertCmd.Parameters.AddWithValue("@JourneyDate", ObjBookTicketBO.JourneyDate)
			InsertCmd.Parameters.AddWithValue("@ServiceNumber", ObjBookTicketBO.ServiceNumber)
			InsertCmd.Parameters.AddWithValue("@NoOfPassengers", ObjBookTicketBO.NoOfPassengers)
			InsertCmd.Parameters.AddWithValue("@AvailableSeats", ObjBookTicketBO.AvailableSeats)
			InsertCmd.Parameters.AddWithValue("@StartTime", ObjBookTicketBO.StartTime)
			InsertCmd.Parameters.AddWithValue("@BusType", ObjBookTicketBO.BusType)
			InsertCmd.Parameters.AddWithValue("@TravelName", ObjBookTicketBO.TravelName)
			InsertCmd.Parameters.AddWithValue("@BoardingPoint", ObjBookTicketBO.BoardingPoint)
			InsertCmd.Parameters.AddWithValue("@TotalAmount", ObjBookTicketBO.TotalAmount)
			InsertCmd.Parameters.AddWithValue("@ServiceTax", ObjBookTicketBO.ServiceTax)
			InsertCmd.Parameters.AddWithValue("@TransactionFee", ObjBookTicketBO.TransactionFee)
			InsertCmd.Parameters.AddWithValue("@NetAmount", ObjBookTicketBO.NetAmount)
			InsertCmd.Parameters.AddWithValue("@Fare", ObjBookTicketBO.Fare)
			InsertCmd.Parameters.AddWithValue("@Phone", ObjBookTicketBO.Phone)
			InsertCmd.Parameters.AddWithValue("@Type", "I"C)
			InsertCmd.ExecuteNonQuery()
			ObjBookTicketBO.TicketID = Convert.ToInt64(ParamUserId.Value.ToString())
			intUserId = ObjBookTicketBO.TicketID
			Return intUserId
		Catch
			Throw
		Finally
			SqlCon.Close()
		End Try
	End Function
End Class
