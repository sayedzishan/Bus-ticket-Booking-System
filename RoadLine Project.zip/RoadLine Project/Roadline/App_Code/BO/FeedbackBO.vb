Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Class FeedbackBO
	Public Sub New()
	End Sub
	Private _FeedbackID As Int64
	Public Property FeedbackID() As Int64
		Get
			Return _FeedbackID
		End Get
		Set
			_FeedbackID = value
		End Set
	End Property
	Private _UserName As String
	Public Property UserName() As String
		Get
			Return _UserName
		End Get
		Set
			_UserName = value
		End Set
	End Property
	Private _Email As String
	Public Property Email() As String
		Get
			Return _Email
		End Get
		Set
			_Email = value
		End Set
	End Property
	Private _Mobile As String
	Public Property Mobile() As String
		Get
			Return _Mobile
		End Get
		Set
			_Mobile = value
		End Set
	End Property
	Private _Subject As String
	Public Property Subject() As String
		Get
			Return _Subject
		End Get
		Set
			_Subject = value
		End Set
	End Property
	Private _Phone As String
	Public Property Phone() As String
		Get
			Return _Phone
		End Get
		Set
			_Phone = value
		End Set
	End Property
	Private _Comments As String
	Public Property Comments() As String
		Get
			Return _Comments
		End Get
		Set
			_Comments = value
		End Set
	End Property
	Private _RatingOfSite As String
	Public Property RatingOfSite() As String
		Get
			Return _RatingOfSite
		End Get
		Set
			_RatingOfSite = value
		End Set
	End Property
	Private _SendDate As DateTime
	Public Property SendDate() As DateTime
		Get
			Return _SendDate
		End Get
		Set
			_SendDate = value
		End Set
	End Property
	Public Function InsertIntotblFeedback() As Integer
		Try
			Dim ObjFeedbackDAL As New FeedbackDAL()
			Return ObjFeedbackDAL.InsertFeedback(Me)
		Catch
			Return 0
		End Try
	End Function
	Public Function ShowFeedback() As DataSet
		Try
			Dim ObjFeedbackDAL As New FeedbackDAL()
			Return ObjFeedbackDAL.ShowFeedbackFromtblFeedback(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function ShowFeedback1() As DataSet
		Try
			Dim ObjFeedbackDAL As New FeedbackDAL()
			Return ObjFeedbackDAL.ShowFeedbackDetailsFromtblFeedback(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function DeleteFromtblFeedback(StrIds As [String]) As [Boolean]
		Try
			Dim ObjFeedbackDAL As New FeedbackDAL()
			Return ObjFeedbackDAL.DeleteFromtblFeedback(StrIds)
		Catch
			Return False
		End Try
	End Function
End Class
