Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Class MailaFriendBO
	Public Sub New()
	End Sub
	Private _ID As Int64
	Public Property ID() As Int64
		Get
			Return _ID
		End Get
		Set
			_ID = value
		End Set
	End Property
	Private _YourEmailID As String
	Public Property YourEmailID() As String
		Get
			Return _YourEmailID
		End Get
		Set
			_YourEmailID = value
		End Set
	End Property
	Private _FriendsEmailID1 As String
	Public Property FriendsEmailID1() As String
		Get
			Return _FriendsEmailID1
		End Get
		Set
			_FriendsEmailID1 = value
		End Set
	End Property
	Private _EmailID2 As String
	Public Property EmailID2() As String
		Get
			Return _EmailID2
		End Get
		Set
			_EmailID2 = value
		End Set
	End Property
	Private _EmailID3 As String
	Public Property EmailID3() As String
		Get
			Return _EmailID3
		End Get
		Set
			_EmailID3 = value
		End Set
	End Property
	Private _EmailID4 As String
	Public Property EmailID4() As String
		Get
			Return _EmailID4
		End Get
		Set
			_EmailID4 = value
		End Set
	End Property
	Private _EmailID5 As String
	Public Property EmailID5() As String
		Get
			Return _EmailID5
		End Get
		Set
			_EmailID5 = value
		End Set
	End Property
	Private _StandardContent As String
	Public Property StandardContent() As String
		Get
			Return _StandardContent
		End Get
		Set
			_StandardContent = value
		End Set
	End Property
	Private _Comments As String
	Public Property Comments() As String
		Get
			Return _Comments
		End Get
		Set
			_Comments = value
		End Set
	End Property
	Private _SendDate As DateTime
	Public Property SendDate() As DateTime
		Get
			Return _SendDate
		End Get
		Set
			_SendDate = value
		End Set
	End Property
	Public Function getEmailId() As DataSet
		Try
			Dim ObjMailaFriendDAL As New MailaFriendDAL()
			Return ObjMailaFriendDAL.getEmailId(Me)
		Catch
			Return Nothing
		End Try
	End Function
End Class
