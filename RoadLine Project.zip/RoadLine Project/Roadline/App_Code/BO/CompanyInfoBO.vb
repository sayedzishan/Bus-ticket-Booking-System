Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Class CompanyInfoBO
	Public Sub New()
	End Sub
	Private _CompanyID As Int64
	Public Property CompanyID() As Int64
		Get
			Return _CompanyID
		End Get
		Set
			_CompanyID = value
		End Set
	End Property
	Private _CompanyName As String
	Public Property CompanyName() As String
		Get
			Return _CompanyName
		End Get
		Set
			_CompanyName = value
		End Set
	End Property
	Private _Description As String
	Public Property Description() As String
		Get
			Return _Description
		End Get
		Set
			_Description = value
		End Set
	End Property
	Private _Address As String
	Public Property Address() As String
		Get
			Return _Address
		End Get
		Set
			_Address = value
		End Set
	End Property
	Private _CompanyLogo As String
	Public Property CompanyLogo() As String
		Get
			Return _CompanyLogo
		End Get
		Set
			_CompanyLogo = value
		End Set
	End Property
	Private _CreatedDate As DateTime
	Public Property CreatedDate() As DateTime
		Get
			Return _CreatedDate
		End Get
		Set
			_CreatedDate = value
		End Set
	End Property
	Private _UpdatedDate As DateTime
	Public Property UpdatedDate() As DateTime
		Get
			Return _UpdatedDate
		End Get
		Set
			_UpdatedDate = value
		End Set
	End Property
	Public Function InsertIntoCompanyInfo() As Integer
		Try
			Dim ObjCompanyInfoDAL As New CompanyInfoDAL()
			Return ObjCompanyInfoDAL.InsertCompanyInfo(Me)
		Catch
			Return 0
		End Try
	End Function
	Public Function GetDataOrderByDate() As DataSet
		Try
			Dim ObjCompanyInfoDAL As New CompanyInfoDAL()
			Return ObjCompanyInfoDAL.GetDataOrderByDate(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function EditCompanyDetails() As DataSet
		Try
			Dim ObjCompanyInfoDAL As New CompanyInfoDAL()
			Return ObjCompanyInfoDAL.EditCompanyDetails(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function UpdatetblCompanyInfo() As Integer
		Try
			Dim ObjCompanyInfoDAL As New CompanyInfoDAL()
			Return ObjCompanyInfoDAL.UpdatetblCompanyInfo(Me)
		Catch
			Return 0
		End Try
	End Function
End Class
