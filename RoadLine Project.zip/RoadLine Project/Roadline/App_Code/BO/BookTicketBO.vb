Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Class BookTicketBO
	Public Sub New()
	End Sub
	Private _TicketID As Int64
	Public Property TicketID() As Int64
		Get
			Return _TicketID
		End Get
		Set
			_TicketID = value
		End Set
	End Property
	Private _FullName As String
	Public Property FullName() As String
		Get
			Return _FullName
		End Get
		Set
			_FullName = value
		End Set
	End Property
	Private _Mobile As String
	Public Property Mobile() As String
		Get
			Return _Mobile
		End Get
		Set
			_Mobile = value
		End Set
	End Property
	Private _Gender As String
	Public Property Gender() As String
		Get
			Return _Gender
		End Get
		Set
			_Gender = value
		End Set
	End Property
	Private _Email As String
	Public Property Email() As String
		Get
			Return _Email
		End Get
		Set
			_Email = value
		End Set
	End Property
	Private _Address As String
	Public Property Address() As String
		Get
			Return _Address
		End Get
		Set
			_Address = value
		End Set
	End Property
	Private _IDCardType As String
	Public Property IDCardType() As String
		Get
			Return _IDCardType
		End Get
		Set
			_IDCardType = value
		End Set
	End Property
	Private _IDCardNumber As String
	Public Property IDCardNumber() As String
		Get
			Return _IDCardNumber
		End Get
		Set
			_IDCardNumber = value
		End Set
	End Property
	Private _IssuingAuthority As String
	Public Property IssuingAuthority() As String
		Get
			Return _IssuingAuthority
		End Get
		Set
			_IssuingAuthority = value
		End Set
	End Property
	Private _PaymentMode As String
	Public Property PaymentMode() As String
		Get
			Return _PaymentMode
		End Get
		Set
			_PaymentMode = value
		End Set
	End Property
	Private _Source As String
	Public Property Source() As String
		Get
			Return _Source
		End Get
		Set
			_Source = value
		End Set
	End Property
	Private _Destination As String
	Public Property Destination() As String
		Get
			Return _Destination
		End Get
		Set
			_Destination = value
		End Set
	End Property
	Private _SeatNumber As String
	Public Property SeatNumber() As String
		Get
			Return _SeatNumber
		End Get
		Set
			_SeatNumber = value
		End Set
	End Property
	Private _JourneyDate As String
	Public Property JourneyDate() As String
		Get
			Return _JourneyDate
		End Get
		Set
			_JourneyDate = value
		End Set
	End Property
	Private _ServiceNumber As String
	Public Property ServiceNumber() As String
		Get
			Return _ServiceNumber
		End Get
		Set
			_ServiceNumber = value
		End Set
	End Property
	Private _NoOfPassengers As String
	Public Property NoOfPassengers() As String
		Get
			Return _NoOfPassengers
		End Get
		Set
			_NoOfPassengers = value
		End Set
	End Property
	Private _BusType As String
	Public Property BusType() As String
		Get
			Return _BusType
		End Get
		Set
			_BusType = value
		End Set
	End Property
	Private _TravelName As String
	Public Property TravelName() As String
		Get
			Return _TravelName
		End Get
		Set
			_TravelName = value
		End Set
	End Property
	Private _BoardingPoint As String
	Public Property BoardingPoint() As String
		Get
			Return _BoardingPoint
		End Get
		Set
			_BoardingPoint = value
		End Set
	End Property
	Private _TotalAmount As String
	Public Property TotalAmount() As String
		Get
			Return _TotalAmount
		End Get
		Set
			_TotalAmount = value
		End Set
	End Property
	Private _ServiceTax As String
	Public Property ServiceTax() As String
		Get
			Return _ServiceTax
		End Get
		Set
			_ServiceTax = value
		End Set
	End Property
	Private _TransactionFee As String
	Public Property TransactionFee() As String
		Get
			Return _TransactionFee
		End Get
		Set
			_TransactionFee = value
		End Set
	End Property
	Private _StartTime As String
	Public Property StartTime() As String
		Get
			Return _StartTime
		End Get
		Set
			_StartTime = value
		End Set
	End Property
	Private _NetAmount As String
	Public Property NetAmount() As String
		Get
			Return _NetAmount
		End Get
		Set
			_NetAmount = value
		End Set
	End Property
	Private _BookedDate As DateTime
	Public Property BookedDate() As DateTime
		Get
			Return _BookedDate
		End Get
		Set
			_BookedDate = value
		End Set
	End Property
	Private _AvailableSeats As String
	Public Property AvailableSeats() As String
		Get
			Return _AvailableSeats
		End Get
		Set
			_AvailableSeats = value
		End Set
	End Property
	Private _Fare As String
	Public Property Fare() As String
		Get
			Return _Fare
		End Get
		Set
			_Fare = value
		End Set
	End Property
	Private _Phone As String
	Public Property Phone() As String
		Get
			Return _Phone
		End Get
		Set
			_Phone = value
		End Set
	End Property
	Public Function GetServiceNumbers() As DataSet
		Try
			Dim ObjBookTicketDAL As New BookTicketDAL()
			Return ObjBookTicketDAL.GetServiceNumbers(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function Record() As DataSet
		Try
			Dim ObjBookTicketDAL As New BookTicketDAL()
			Return ObjBookTicketDAL.Record(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function InsertIntotblBookTicket() As Int64
		Try
			Dim ObjBookTicketDAL As New BookTicketDAL()
			Return ObjBookTicketDAL.InsertIntotblBookTicket(Me)
		Catch
			Return 0
		End Try
	End Function
End Class
