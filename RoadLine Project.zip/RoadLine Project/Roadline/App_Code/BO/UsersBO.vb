Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Class UsersBO
	Public Sub New()
	End Sub
	Private _UserID As Int64
	Public Property UserID() As Int64
		Get
			Return _UserID
		End Get
		Set
			_UserID = value
		End Set
	End Property
	Private _UserName As String
	Public Property UserName() As String
		Get
			Return _UserName
		End Get
		Set
			_UserName = value
		End Set
	End Property
	Private _Password As String
	Public Property Password() As String
		Get
			Return _Password
		End Get
		Set
			_Password = value
		End Set
	End Property
	Private _Email As String
	Public Property Email() As String
		Get
			Return _Email
		End Get
		Set
			_Email = value
		End Set
	End Property
	Private _Mobile As String
	Public Property Mobile() As String
		Get
			Return _Mobile
		End Get
		Set
			_Mobile = value
		End Set
	End Property
	Private _Phone As String
	Public Property Phone() As String
		Get
			Return _Phone
		End Get
		Set
			_Phone = value
		End Set
	End Property
	Private _Country As String
	Public Property Country() As String
		Get
			Return _Country
		End Get
		Set
			_Country = value
		End Set
	End Property
	Private _City As String
	Public Property City() As String
		Get
			Return _City
		End Get
		Set
			_City = value
		End Set
	End Property
	Private _Address As String
	Public Property Address() As String
		Get
			Return _Address
		End Get
		Set
			_Address = value
		End Set
	End Property
	Private _CreatedDate As DateTime
	Public Property CreatedDate() As DateTime
		Get
			Return _CreatedDate
		End Get
		Set
			_CreatedDate = value
		End Set
	End Property
	Private _UpdatedDate As DateTime
	Public Property UpdatedDate() As DateTime
		Get
			Return _UpdatedDate
		End Get
		Set
			_UpdatedDate = value
		End Set
	End Property
	Private _Status As String
	Public Property Status() As String
		Get
			Return _Status
		End Get
		Set
			_Status = value
		End Set
	End Property
	Public Function InsertIntotblUsers() As Int64
		Try
			Dim ObjUsersDAL As New UsersDAL()
			Return ObjUsersDAL.InsertIntotblUsers(Me)
		Catch
			Return 0
		End Try
	End Function
	Public Function CheckAvailable() As DataSet
		Try
			Dim ObjUsersDAL As New UsersDAL()
			Return ObjUsersDAL.CheckAvailability(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function ShowUsersInfo() As DataSet
		Try
			Dim ObjUsersDAL As New UsersDAL()
			Return ObjUsersDAL.ShowUsersInfo(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function ShowUsersInfo1() As DataSet
		Try
			Dim ObjUsersDAL As New UsersDAL()
			Return ObjUsersDAL.ShowUsersInfo1(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function UpdatetblUsers() As Integer
		Try
			Dim ObjUsersDAL As New UsersDAL()
			Return ObjUsersDAL.UpdatetblUsers(Me)
		Catch
			Return 0
		End Try
	End Function
	Public Function ChangePassword() As Integer
		Try
			Dim ObjUsersDAL As New UsersDAL()
			Return ObjUsersDAL.ChangePassword(Me)
		Catch
			Return 0
		End Try
	End Function
	Public Function ShowUserById() As DataSet
		Try
			Dim ObjUsersDAL As New UsersDAL()
			Return ObjUsersDAL.ShowUsers(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function GetDataOrderByDate() As DataSet
		Try
			Dim ObjUsersDAL As New UsersDAL()
			Return ObjUsersDAL.ShowUsers(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function EditUserDetails() As DataSet
		Try
			Dim ObjUsersDAL As New UsersDAL()
			Return ObjUsersDAL.EditUserDetails(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function DeleteFromtblUsers(StrIds As [String]) As [Boolean]
		Try
			Dim ObjUsersDAL As New UsersDAL()
			Return ObjUsersDAL.DeleteFromtblUsers(StrIds)
		Catch
			Return False
		End Try
	End Function
	Public Function UpdateUserStatus() As Integer
		Try
			Dim objUsersDAL As New UsersDAL()
			Return objUsersDAL.UpdateUserStatus(Me)
		Catch
			Return 0
		End Try
	End Function
	Public Function CheckLogin() As DataSet
		Try
			Dim ObjUsersDAL As New UsersDAL()
			Return ObjUsersDAL.CheckLogin(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function ForgotPasswordForEmail(Email As String) As DataSet
		Try
			Dim ObjUsersDAL As New UsersDAL()
			Return ObjUsersDAL.ForgotPasswordforEamil(Email)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function ForgotPassword() As DataSet
		Try
			Dim ObjUsersDAL As New UsersDAL()
			Return ObjUsersDAL.ForgotPassword(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function Login(check As String) As DataSet
		Try
			Dim ObjUsersDAL As New UsersDAL()
			Return ObjUsersDAL.Login(Me, check)
		Catch
			Return Nothing
		End Try
	End Function
End Class
