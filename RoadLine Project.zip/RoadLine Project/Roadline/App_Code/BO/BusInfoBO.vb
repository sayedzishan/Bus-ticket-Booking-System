Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Class BusInfoBO
	Public Sub New()
	End Sub
	Private _ServiceID As Int64
	Public Property ServiceID() As Int64
		Get
			Return _ServiceID
		End Get
		Set
			_ServiceID = value
		End Set
	End Property
	Private _ServiceName As String
	Public Property ServiceName() As String
		Get
			Return _ServiceName
		End Get
		Set
			_ServiceName = value
		End Set
	End Property
	Private _ServiceNumber As String
	Public Property ServiceNumber() As String
		Get
			Return _ServiceNumber
		End Get
		Set
			_ServiceNumber = value
		End Set
	End Property
	Private _TravelName As String
	Public Property TravelName() As String
		Get
			Return _TravelName
		End Get
		Set
			_TravelName = value
		End Set
	End Property
	Private _BusType As String
	Public Property BusType() As String
		Get
			Return _BusType
		End Get
		Set
			_BusType = value
		End Set
	End Property
	Private _Source As String
	Public Property Source() As String
		Get
			Return _Source
		End Get
		Set
			_Source = value
		End Set
	End Property
	Private _Destination As String
	Public Property Destination() As String
		Get
			Return _Destination
		End Get
		Set
			_Destination = value
		End Set
	End Property
	Private _StartTime As String
	Public Property StartTime() As String
		Get
			Return _StartTime
		End Get
		Set
			_StartTime = value
		End Set
	End Property
	Private _ReachTime As String
	Public Property ReachTime() As String
		Get
			Return _ReachTime
		End Get
		Set
			_ReachTime = value
		End Set
	End Property
	Private _Fare As String
	Public Property Fare() As String
		Get
			Return _Fare
		End Get
		Set
			_Fare = value
		End Set
	End Property
	Private _NoOfSeatsAvailable As String
	Public Property NoOfSeatsAvailable() As String
		Get
			Return _NoOfSeatsAvailable
		End Get
		Set
			_NoOfSeatsAvailable = value
		End Set
	End Property
	Private _DateOfJourney As DateTime
	Public Property DateOfJourney() As DateTime
		Get
			Return _DateOfJourney
		End Get
		Set
			_DateOfJourney = value
		End Set
	End Property
	Private _AllotedDate As DateTime
	Public Property AllotedDate() As DateTime
		Get
			Return _AllotedDate
		End Get
		Set
			_AllotedDate = value
		End Set
	End Property
	Public Function InsertIntoBusInfo() As Integer
		Try
			Dim ObjBusInfoDAL As New BusInfoDAL()
			Return ObjBusInfoDAL.InsertIntoBusInfo(Me)
		Catch
			Return 0
		End Try
	End Function
	Public Function ShowBusDetails() As DataSet
		Try
			Dim ObjBusInfoDAL As New BusInfoDAL()
			Return ObjBusInfoDAL.ShowBusDetails(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function EditBusDetails() As DataSet
		Try
			Dim ObjBusInfoDAL As New BusInfoDAL()
			Return ObjBusInfoDAL.EditBusDetails(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function DeleteFromtblBusInfo(StrIds As [String]) As [Boolean]
		Try
			Dim ObjBusInfoDAL As New BusInfoDAL()
			Return ObjBusInfoDAL.DeleteFromtblBusInfo(StrIds)
		Catch
			Return False
		End Try
	End Function
	Public Function UpdatetblBusInfo() As Integer
		Try
			Dim ObjBusInfoDAL As New BusInfoDAL()
			Return ObjBusInfoDAL.UpdatetblBusInfo(Me)
		Catch
			Return 0
		End Try
	End Function
	Public Function SearchDetails(SearchString As String) As DataSet
		Try
			Dim ObjBusInfoDAL As New BusInfoDAL()
			Return ObjBusInfoDAL.SearchDetails(SearchString)
		Catch
			Return Nothing
		End Try
	End Function
End Class
