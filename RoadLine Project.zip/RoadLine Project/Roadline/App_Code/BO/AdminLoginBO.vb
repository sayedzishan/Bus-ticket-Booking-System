Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Class AdminLoginBO
	Public Sub New()
	End Sub
	Private _ID As Integer
	Public Property ID() As Integer
		Get
			Return _ID
		End Get
		Set
			_ID = value
		End Set
	End Property
	Private _UserName As String
	Public Property UserName() As String
		Get
			Return _UserName
		End Get
		Set
			_UserName = value
		End Set
	End Property
	Private _Password As String
	Public Property Password() As String
		Get
			Return _Password
		End Get
		Set
			_Password = value
		End Set
	End Property
End Class
