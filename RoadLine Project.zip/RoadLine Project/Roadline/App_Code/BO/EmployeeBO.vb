Imports System
Imports System.Data
Imports System.Configuration
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Class EmployeeBO
	Public Sub New()
	End Sub
	Private _EmployeeID As Int64
	Public Property EmployeeID() As Int64
		Get
			Return _EmployeeID
		End Get
		Set
			_EmployeeID = value
		End Set
	End Property
	Private _EmployeeName As String
	Public Property EmployeeName() As String
		Get
			Return _EmployeeName
		End Get
		Set
			_EmployeeName = value
		End Set
	End Property
	Private _Designation As String
	Public Property Designation() As String
		Get
			Return _Designation
		End Get
		Set
			_Designation = value
		End Set
	End Property
	Private _Email As String
	Public Property Email() As String
		Get
			Return _Email
		End Get
		Set
			_Email = value
		End Set
	End Property
	Private _Address As String
	Public Property Address() As String
		Get
			Return _Address
		End Get
		Set
			_Address = value
		End Set
	End Property
	Private _Mobile As String
	Public Property Mobile() As String
		Get
			Return _Mobile
		End Get
		Set
			_Mobile = value
		End Set
	End Property
	Private _AllotedToBranch As String
	Public Property AllotedToBranch() As String
		Get
			Return _AllotedToBranch
		End Get
		Set
			_AllotedToBranch = value
		End Set
	End Property
	Private _CreatedDate As DateTime
	Public Property CreatedDate() As DateTime
		Get
			Return _CreatedDate
		End Get
		Set
			_CreatedDate = value
		End Set
	End Property
	Public Function InsertIntoEmployeeInfo() As Integer
		Try
			Dim ObjEmployeeDAL As New EmployeeDAL()
			Return ObjEmployeeDAL.InsertEmployeeInfo(Me)
		Catch
			Return 0
		End Try
	End Function
	Public Function ShowEmployeeDetails() As DataSet
		Try
			Dim ObjEmployeeDAL As New EmployeeDAL()
			Return ObjEmployeeDAL.ShowEmployeeDetails(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function UpdatetblEmployees() As Integer
		Try
			Dim ObjEmployeeDAL As New EmployeeDAL()
			Return ObjEmployeeDAL.UpdatetblEmployees(Me)
		Catch
			Return 0
		End Try
	End Function
	Public Function ShowEmployee() As DataSet
		Try
			Dim ObjEmployeeDAL As New EmployeeDAL()
			Return ObjEmployeeDAL.ShowEmployee(Me)
		Catch
			Return Nothing
		End Try
	End Function
	Public Function DeleteFromtblEmployees(StrIds As [String]) As [Boolean]
		Try
			Dim ObjEmployeeDAL As New EmployeeDAL()
			Return ObjEmployeeDAL.DeleteFromtblEmployees(StrIds)
		Catch
			Return False
		End Try
	End Function
End Class
