Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class ADMIN_ViewFeedback
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("ID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
			ShowFeedbackDetails()
		End If
	End Sub
	Private Sub ShowFeedbackDetails()
		Dim ObjFeedbackBO As New FeedbackBO()
		If Request.QueryString("Id") IsNot Nothing Then
			ObjFeedbackBO.FeedbackID = Convert.ToInt16(Request.QueryString("Id"))
		End If
		Dim DsGetDataById As New DataSet()
		DsGetDataById = ObjFeedbackBO.ShowFeedback1()
		If DsGetDataById IsNot Nothing Then
			If DsGetDataById.Tables(0).Rows.Count > 0 Then
				If DsGetDataById.Tables(0).Rows(0)("UserName").ToString() <> "" Then
					txtName.Text = DsGetDataById.Tables(0).Rows(0)("UserName").ToString()
				Else
					txtName.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Email").ToString() <> "" Then
					txtEmail.Text = DsGetDataById.Tables(0).Rows(0)("Email").ToString()
				Else
					txtEmail.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Comments").ToString() <> "" Then
					txtComments.Text = DsGetDataById.Tables(0).Rows(0)("Comments").ToString()
				Else
					txtComments.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("RatingOfSite").ToString() <> "" Then
					lblRating.Text = DsGetDataById.Tables(0).Rows(0)("RatingOfSite").ToString()
				Else
					lblRating.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("SendDate").ToString() <> "" Then
					lblCreatedDate.Text = DsGetDataById.Tables(0).Rows(0)("SendDate").ToString()
				Else
					lblCreatedDate.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Mobile").ToString() <> "" Then
					txtMobileCountry.Text = DsGetDataById.Tables(0).Rows(0)("Mobile").ToString().Replace("~"C, "-"C)
				Else
					txtMobileCountry.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Phone").ToString() <> "" Then
					txtPhCountry1.Text = DsGetDataById.Tables(0).Rows(0)("Phone").ToString().Replace("~"C, "-"C)
				Else
					txtPhCountry1.Text = "Not Mentioned"
				End If
			End If
		End If
	End Sub
	Protected Sub Button1_Click(sender As Object, e As EventArgs)
		Response.Redirect("MaintainFeedback.aspx")
	End Sub
End Class
