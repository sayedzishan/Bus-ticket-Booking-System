Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class ADMIN_ShowUserDetails
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("ID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
			ShowUserDetails()
		End If
	End Sub
	Private Sub ShowUserDetails()
		Dim ObjUsersBO As New UsersBO()
		If Request.QueryString("Id") IsNot Nothing Then
			ObjUsersBO.UserID = Convert.ToInt16(Request.QueryString("Id"))
		End If
		Dim DsGetDataById As New DataSet()
		DsGetDataById = ObjUsersBO.EditUserDetails()
		If DsGetDataById IsNot Nothing Then
			If DsGetDataById.Tables(0).Rows.Count > 0 Then
				If DsGetDataById.Tables(0).Rows(0)("UserName").ToString() <> "" Then
					txtUserName.Text = DsGetDataById.Tables(0).Rows(0)("UserName").ToString()
				Else
					txtUserName.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Email").ToString() <> "" Then
					txtEmail.Text = DsGetDataById.Tables(0).Rows(0)("Email").ToString()
				Else
					txtEmail.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Country").ToString() <> "" Then
					lblCountry.Text = DsGetDataById.Tables(0).Rows(0)("Country").ToString()
				Else
					lblCountry.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("CreatedDate").ToString() <> "" Then
					lblCreatedDate.Text = DsGetDataById.Tables(0).Rows(0)("CreatedDate").ToString()
				Else
					lblCreatedDate.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("City").ToString() <> "" Then
					txtCity.Text = DsGetDataById.Tables(0).Rows(0)("City").ToString()
				Else
					txtCity.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Address").ToString() <> "" Then
					txtAddress.Text = DsGetDataById.Tables(0).Rows(0)("Address").ToString()
				Else
					txtAddress.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Mobile").ToString() <> "" Then
					Dim strMobile As String() = (DsGetDataById.Tables(0).Rows(0)("Mobile").ToString()).Split("~"C)
					txtMobileCountry.Text = strMobile(0).ToString()
					txtMobile.Text = strMobile(1).ToString()
				Else
					txtMobileCountry.Text = " "
				End If
				If DsGetDataById.Tables(0).Rows(0)("Phone").ToString() <> "" Then
					Dim strPh As String() = (DsGetDataById.Tables(0).Rows(0)("Phone").ToString()).Split("~"C)
					txtPhCountry.Text = strPh(0).ToString()
					txtPhSTD.Text = strPh(1).ToString()
					txtPhone.Text = strPh(2).ToString()
				End If
			End If
		End If
	End Sub
	Protected Sub btnBack_Click(sender As Object, e As EventArgs)
		Response.Redirect("MaintainUsers.aspx")
	End Sub
End Class
