Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class ADMIN_MaintainCompanyInfo
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("ID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
			ShowCompanyInfo()
		End If
	End Sub
	Private Sub ShowCompanyInfo()
		Try
			Dim objCompanyInfoBO As New CompanyInfoBO()
			Dim DsGetDataOrderByDate As New DataSet()
			DsGetDataOrderByDate = objCompanyInfoBO.GetDataOrderByDate()
			If DsGetDataOrderByDate IsNot Nothing Then
				If DsGetDataOrderByDate.Tables(0).Rows.Count > 0 Then
					dgCompanyInfo.DataSource = DsGetDataOrderByDate
					dgCompanyInfo.DataBind()
				End If
			Else
				dgCompanyInfo.DataSource = Nothing
				dgCompanyInfo.DataBind()
			End If
		Catch
			dgCompanyInfo.DataSource = Nothing
			dgCompanyInfo.DataBind()
		End Try
	End Sub
	Protected Sub dgCompanyInfo_ItemCommand(source As Object, e As DataGridCommandEventArgs)
		If e.CommandName = "Edit" Then
			Response.Redirect("EditCompanyInfo.aspx?Id=" + dgCompanyInfo.DataKeys(e.Item.ItemIndex))
		End If
	End Sub
End Class
