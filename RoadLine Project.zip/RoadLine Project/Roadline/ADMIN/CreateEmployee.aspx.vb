Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class ADMIN_CreateEmployee
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("ID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
		End If
	End Sub
	Protected Sub Button1_Click(sender As Object, e As EventArgs)
		Try
			Dim intResult As Integer = 0
			Dim ObjEmployeeBO As New EmployeeBO()
			ObjEmployeeBO.EmployeeName = txtEmployeeName.Text.Trim()
			ObjEmployeeBO.Email = txtEmail.Text.Trim()
			ObjEmployeeBO.Address = txtAddress.Text.Trim()
			ObjEmployeeBO.Designation = txtDesignation.Text.Trim()
			If txtMobileCountry.Text.Trim() <> "" AndAlso txtMobile.Text.Trim() <> "" Then
				ObjEmployeeBO.Mobile = txtMobileCountry.Text.Trim() + "~" + txtMobile.Text.Trim()
			End If
			If ddlBranch.SelectedIndex <> 0 Then
				ObjEmployeeBO.AllotedToBranch = ddlBranch.SelectedItem.Text
			End If
			intResult = ObjEmployeeBO.InsertIntoEmployeeInfo()
			If intResult > 0 Then
				Page.RegisterStartupScript("SS", "<script> alert('Succesfully Created The Employee Details'); </script>")
				txtEmployeeName.Text = ""
				txtEmail.Text = ""
				txtAddress.Text = ""
				txtDesignation.Text = ""
				txtMobileCountry.Text = ""
				ddlBranch.SelectedIndex = 0
				txtMobile.Text = ""
			Else
			End If
		Catch
			Throw
		End Try
	End Sub
	Protected Sub brnBack_Click(sender As Object, e As EventArgs)
		Response.Redirect("MaintainEmployees.aspx")
	End Sub
End Class
