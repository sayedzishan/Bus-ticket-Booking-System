Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class ADMIN_EditBusInfo
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("ID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
			EditBusDetails()
		End If
	End Sub
	Private Sub EditBusDetails()
		Dim ObjBusInfoBO As New BusInfoBO()
		If Request.QueryString("Id") IsNot Nothing Then
			ObjBusInfoBO.ServiceID = Convert.ToInt16(Request.QueryString("Id"))
		End If
		Dim DsGetDataById As New DataSet()
		DsGetDataById = ObjBusInfoBO.EditBusDetails()
		If DsGetDataById IsNot Nothing Then
			If DsGetDataById.Tables(0).Rows.Count > 0 Then
				If DsGetDataById.Tables(0).Rows(0)("ServiceName").ToString() <> "" Then
					txtServiceName.Text = DsGetDataById.Tables(0).Rows(0)("ServiceName").ToString()
				Else
					txtServiceName.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("ServiceNumber").ToString() <> "" Then
					txtServiceNumber.Text = DsGetDataById.Tables(0).Rows(0)("ServiceNumber").ToString()
				Else
					txtServiceNumber.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("TravelName").ToString() <> "" Then
					txtTravelName.Text = DsGetDataById.Tables(0).Rows(0)("TravelName").ToString()
				Else
					txtTravelName.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("StartTime").ToString() <> "" Then
					txtTime.Text = DsGetDataById.Tables(0).Rows(0)("StartTime").ToString()
				Else
					txtTime.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("DateOfJourney").ToString() <> "" Then
					txtDateOfJourney.Text = DsGetDataById.Tables(0).Rows(0)("DateOfJourney").ToString()
				Else
					txtDateOfJourney.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("NoOfSeatsAvailable").ToString() <> "" Then
					txtNoOfSeatsAvailable.Text = DsGetDataById.Tables(0).Rows(0)("NoOfSeatsAvailable").ToString()
				Else
					txtNoOfSeatsAvailable.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Fare").ToString() <> "" Then
					txtFare.Text = DsGetDataById.Tables(0).Rows(0)("Fare").ToString()
				Else
					txtFare.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("BusType").ToString() <> "" Then
					ddlBusType.Text = DsGetDataById.Tables(0).Rows(0)("BusType").ToString()
				Else
					ddlBusType.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Source").ToString() <> "" Then
					ddlSource.Text = DsGetDataById.Tables(0).Rows(0)("Source").ToString()
				Else
					ddlSource.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Destination").ToString() <> "" Then
					ddlDestination.Text = DsGetDataById.Tables(0).Rows(0)("Destination").ToString()
				Else
					ddlDestination.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("AllotedDate").ToString() <> "" Then
					lblAllotedDate.Text = DsGetDataById.Tables(0).Rows(0)("AllotedDate").ToString()
				Else
					lblAllotedDate.Text = "Not Mentioned"
				End If
			End If
		End If
	End Sub
	Private Sub UpdatetblBusInfo()
		Try
			Dim intResult As Integer = 0
			Dim ObjBusInfoBO As New BusInfoBO()
			ObjBusInfoBO.ServiceID = Integer.Parse(Request.QueryString("Id").ToString())
			ObjBusInfoBO.DateOfJourney = Convert.ToDateTime(txtDateOfJourney.Text.Trim())
			ObjBusInfoBO.Fare = txtFare.Text.Trim()
			ObjBusInfoBO.NoOfSeatsAvailable = txtNoOfSeatsAvailable.Text.Trim()
			ObjBusInfoBO.ServiceName = txtServiceName.Text.Trim()
			ObjBusInfoBO.ServiceNumber = txtServiceNumber.Text.Trim()
			ObjBusInfoBO.StartTime = txtTime.Text.Trim()
			ObjBusInfoBO.TravelName = txtTravelName.Text.Trim()
			If ddlBusType.SelectedIndex <> 0 Then
				ObjBusInfoBO.BusType = ddlBusType.SelectedItem.Text
			End If
			If ddlSource.SelectedIndex <> 0 Then
				ObjBusInfoBO.Source = ddlSource.SelectedItem.Text
			End If
			If ddlDestination.SelectedIndex <> 0 Then
				ObjBusInfoBO.Destination = ddlDestination.SelectedItem.Text
			End If
			intResult = ObjBusInfoBO.UpdatetblBusInfo()
			If intResult > 0 Then
				Page.RegisterStartupScript("SS", "<script> alert('Updated Succesfully'); </script>")
				txtServiceName.Text = ""
				txtServiceNumber.Text = ""
				txtTravelName.Text = ""
				txtFare.Text = ""
				txtNoOfSeatsAvailable.Text = ""
				ddlDestination.SelectedIndex = 0
				ddlSource.SelectedIndex = 0
				ddlBusType.SelectedIndex = 0
				txtTime.Text = ""
				txtDateOfJourney.Text = ""
			Else
				lblError.Text = "Error while Creation"
			End If
		Catch
			Throw
		End Try
	End Sub
	Protected Sub btnSave_Click(sender As Object, e As EventArgs)
		UpdatetblBusInfo()
	End Sub
	Protected Sub btnCancel_Click1(sender As Object, e As EventArgs)
		Response.Redirect("MaintainBusInfo.aspx")
	End Sub
End Class
