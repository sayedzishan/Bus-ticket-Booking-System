Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class ADMIN_MaintainFeedback
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("ID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
			ShowFeedback()
		End If
	End Sub
	Private Sub ShowFeedback()
		Try
			Dim objFeedbackBO As New FeedbackBO()
			Dim ds As New DataSet()
			ds = objFeedbackBO.ShowFeedback()
			If ds IsNot Nothing Then
				If ds.Tables(0).Rows.Count > 0 Then
					dgFeedback.DataSource = ds
					dgFeedback.DataBind()
				End If
			Else
				dgFeedback.DataSource = Nothing
				dgFeedback.DataBind()
			End If
		Catch
			dgFeedback.DataSource = Nothing
			dgFeedback.DataBind()
		End Try
	End Sub
	Protected Sub dgFeedback_ItemCommand(source As Object, e As DataGridCommandEventArgs)
		If e.CommandName = "Edit" Then
			Response.Redirect("ViewFeedback.aspx?Id=" + dgFeedback.DataKeys(e.Item.ItemIndex))
		End If
	End Sub
	Protected Sub lnkCheckAll_Click(sender As Object, e As EventArgs)
		lblError.Text = ""
		Dim i As Integer = 0
		While i < dgFeedback.Items.Count
			Dim chk As CheckBox = CType(dgFeedback.Items(i).FindControl("chkDel"), CheckBox)
			chk.Checked = True
			System.Math.Max(System.Threading.Interlocked.Increment(i),i - 1)
		End While
	End Sub
	Protected Sub lnkClearAll_Click(sender As Object, e As EventArgs)
		lblError.Text = ""
		Dim i As Integer = 0
		While i < dgFeedback.Items.Count
			Dim chk As CheckBox = CType(dgFeedback.Items(i).FindControl("chkDel"), CheckBox)
			chk.Checked = False
			System.Math.Max(System.Threading.Interlocked.Increment(i),i - 1)
		End While
	End Sub
	Protected Sub lnlDelete_Click(sender As Object, e As EventArgs)
		Try
			Dim Ids As [String] = ""
			Dim i As Int16 = 0
			While i < dgFeedback.Items.Count
				If (CType(dgFeedback.Items(i).FindControl("chkDel"), CheckBox)).Checked = True Then
					Ids += dgFeedback.DataKeys(i) + ","
				End If
                '	System.Math.Max(System.Threading.Interlocked.Increment(i),i - 1)
                i = i + 1
			End While
			If Ids <> "" Then
				Ids = Ids.TrimEnd(","C)
				Dim Result As [Boolean] = False
				Dim ObjFeedbackBO As New FeedbackBO()
				Result = ObjFeedbackBO.DeleteFromtblFeedback(Ids)
				If Result Then
					ShowFeedback()
					lblError.Text = "Feedback Details deleted successfully"
				Else
					lblError.Text = "Error in deletion"
				End If
			Else
				lblError.Text = "Select a record to delete"
			End If
		Catch
		End Try
	End Sub
End Class
