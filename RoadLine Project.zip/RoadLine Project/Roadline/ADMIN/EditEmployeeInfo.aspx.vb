Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class ADMIN_EditEmployeeInfo
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("ID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
			DisplayEmployeeDetails()
		End If
	End Sub
	Private Sub DisplayEmployeeDetails()
		Dim ObjEmployeeBO As New EmployeeBO()
		If Request.QueryString("Id") IsNot Nothing Then
			ObjEmployeeBO.EmployeeID = Convert.ToInt16(Request.QueryString("Id"))
		End If
		Dim DsGetDataById As New DataSet()
		DsGetDataById = ObjEmployeeBO.ShowEmployeeDetails()
		If DsGetDataById IsNot Nothing Then
			If DsGetDataById.Tables(0).Rows.Count > 0 Then
				If DsGetDataById.Tables(0).Rows(0)("EmployeeName").ToString() <> "" Then
					txtEmployeeName.Text = DsGetDataById.Tables(0).Rows(0)("EmployeeName").ToString()
				Else
					txtEmployeeName.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Email").ToString() <> "" Then
					txtEmail.Text = DsGetDataById.Tables(0).Rows(0)("Email").ToString()
				Else
					txtEmail.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Designation").ToString() <> "" Then
					txtDesignation.Text = DsGetDataById.Tables(0).Rows(0)("Designation").ToString()
				Else
					txtDesignation.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Address").ToString() <> "" Then
					txtAddress.Text = DsGetDataById.Tables(0).Rows(0)("Address").ToString()
				Else
					txtAddress.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("AllotedToBranch").ToString() <> "" Then
					ddlBranch.Text = DsGetDataById.Tables(0).Rows(0)("AllotedToBranch").ToString()
				Else
					ddlBranch.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("CreatedDate").ToString() <> "" Then
					lblCreatedDate.Text = DsGetDataById.Tables(0).Rows(0)("CreatedDate").ToString()
				Else
					lblCreatedDate.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Mobile").ToString() <> "" Then
					Dim strMobile As String() = (DsGetDataById.Tables(0).Rows(0)("Mobile").ToString()).Split("~"C)
					txtMobileCountry.Text = strMobile(0).ToString()
					txtMobile.Text = strMobile(1).ToString()
				Else
					txtMobileCountry.Text = " "
				End If
			End If
		End If
	End Sub
	Private Sub UpdatetblEmployees()
		Try
			Dim intResult As Integer = 0
			Dim ObjEmployeeBO As New EmployeeBO()
			ObjEmployeeBO.EmployeeID = Integer.Parse(Request.QueryString("Id").ToString())
			ObjEmployeeBO.EmployeeName = txtEmployeeName.Text.Trim()
			ObjEmployeeBO.Designation = txtDesignation.Text.Trim()
			ObjEmployeeBO.Address = txtAddress.Text.Trim()
			ObjEmployeeBO.Email = txtEmail.Text.Trim()
			If txtMobileCountry.Text.Trim() <> "" AndAlso txtMobile.Text.Trim() <> "" Then
				ObjEmployeeBO.Mobile = txtMobileCountry.Text.Trim() + "~" + txtMobile.Text.Trim()
			End If
			If ddlBranch.SelectedIndex <> 0 Then
				ObjEmployeeBO.AllotedToBranch = ddlBranch.SelectedItem.Text
			End If
			intResult = ObjEmployeeBO.UpdatetblEmployees()
			If intResult > 0 Then
				Page.RegisterStartupScript("SS", "<script> alert('Updated Succesfully'); </script>")
				txtEmployeeName.Text = ""
				txtEmail.Text = ""
				txtAddress.Text = ""
				txtDesignation.Text = ""
				txtMobileCountry.Text = ""
				ddlBranch.SelectedIndex = 0
				txtMobile.Text = ""
			Else
				lblError.Text = "Error while Creation"
			End If
		Catch
			Throw
		End Try
	End Sub
	Protected Sub btnSave_Click(sender As Object, e As EventArgs)
		UpdatetblEmployees()
	End Sub
	Protected Sub btnCancel_Click(sender As Object, e As EventArgs)
		Response.Redirect("MaintainEmployees.aspx")
	End Sub
End Class
