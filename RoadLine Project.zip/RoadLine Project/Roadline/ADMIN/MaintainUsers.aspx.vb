Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class ADMIN_MaintainUsers
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("ID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
			ShowUser()
		End If
	End Sub
	Private Sub ShowUser()
		Try
			Dim objUsersBO As New UsersBO()
			Dim ds As New DataSet()
			ds = objUsersBO.ShowUsersInfo1()
			If ds IsNot Nothing Then
				If ds.Tables(0).Rows.Count > 0 Then
					dgUsers.DataSource = ds
					dgUsers.DataBind()
				End If
			Else
				dgUsers.DataSource = Nothing
				dgUsers.DataBind()
			End If
		Catch
			dgUsers.DataSource = Nothing
			dgUsers.DataBind()
		End Try
	End Sub
	Protected Sub lnkCheckAll_Click(sender As Object, e As EventArgs)
		lblError.Text = ""
		Dim i As Integer = 0
		While i < dgUsers.Items.Count
			Dim chk As CheckBox = CType(dgUsers.Items(i).FindControl("chkDel"), CheckBox)
			chk.Checked = True
			System.Math.Max(System.Threading.Interlocked.Increment(i),i - 1)
		End While
	End Sub
	Protected Sub lnkClearAll_Click(sender As Object, e As EventArgs)
		lblError.Text = ""
		Dim i As Integer = 0
		While i < dgUsers.Items.Count
			Dim chk As CheckBox = CType(dgUsers.Items(i).FindControl("chkDel"), CheckBox)
			chk.Checked = False
			System.Math.Max(System.Threading.Interlocked.Increment(i),i - 1)
		End While
	End Sub
	Protected Sub lnlDelete_Click(sender As Object, e As EventArgs)
		Try
			Dim Ids As [String] = ""
			Dim i As Int16 = 0
			While i < dgUsers.Items.Count
				If (CType(dgUsers.Items(i).FindControl("chkDel"), CheckBox)).Checked = True Then
					Ids += dgUsers.DataKeys(i) + ","
				End If
                'System.Math.Max(System.Threading.Interlocked.Increment(i), i - 1)
                i = i + 1
			End While
			If Ids <> "" Then
				Ids = Ids.TrimEnd(","C)
				Dim Result As [Boolean] = False
				Dim objUsersBO As New UsersBO()
				Result = objUsersBO.DeleteFromtblUsers(Ids)
				If Result Then
					ShowUser()
					lblError.Text = "User Details deleted successfully"
				Else
					lblError.Text = "Error in deletion"
				End If
			Else
				lblError.Text = "Select a record to delete"
			End If
		Catch
		End Try
	End Sub
	Protected Sub dgUsers_ItemCommand(source As Object, e As DataGridCommandEventArgs)
		If e.CommandName = "Edit" Then
            Response.Redirect("ShowUserDetails.aspx?Id=" & dgUsers.DataKeys(e.Item.ItemIndex))
		End If
	End Sub
End Class
