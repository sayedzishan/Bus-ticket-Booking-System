Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class ADMIN_EditCompanyInfo
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("ID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
			EditCompanyDetails()
		End If
	End Sub
	Private Sub EditCompanyDetails()
		Dim ObjCompanyInfoBO As New CompanyInfoBO()
		If Request.QueryString("Id") IsNot Nothing Then
			ObjCompanyInfoBO.CompanyID = Convert.ToInt16(Request.QueryString("Id"))
		End If
		Dim DsGetDataById As New DataSet()
		DsGetDataById = ObjCompanyInfoBO.EditCompanyDetails()
		If DsGetDataById IsNot Nothing Then
			If DsGetDataById.Tables(0).Rows.Count > 0 Then
				If DsGetDataById.Tables(0).Rows(0)("CompanyName").ToString() <> "" Then
					txtCompanyName.Text = DsGetDataById.Tables(0).Rows(0)("CompanyName").ToString()
				Else
					txtCompanyName.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Description").ToString() <> "" Then
					txtDescription.Text = DsGetDataById.Tables(0).Rows(0)("Description").ToString()
				Else
					txtDescription.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Address").ToString() <> "" Then
					txtAddress.Text = DsGetDataById.Tables(0).Rows(0)("Address").ToString()
				Else
					txtAddress.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("CreatedDate").ToString() <> "" Then
					lblCreatedDate.Text = DsGetDataById.Tables(0).Rows(0)("CreatedDate").ToString()
				Else
					lblCreatedDate.Text = "Not Mentioned"
				End If
			End If
		End If
	End Sub
	Protected Sub btnBack_Click(sender As Object, e As EventArgs)
		Response.Redirect("MaintainCompanyInfo.aspx")
	End Sub
	Private Sub UpdatetblCompanyInfo()
		Try
			Dim intResult As Integer = 0
			Dim ObjCompanyInfoBO As New CompanyInfoBO()
			ObjCompanyInfoBO.CompanyID = Integer.Parse(Request.QueryString("Id").ToString())
			ObjCompanyInfoBO.CompanyName = txtCompanyName.Text.Trim()
			ObjCompanyInfoBO.Description = txtDescription.Text.Trim()
			ObjCompanyInfoBO.Address = txtAddress.Text.Trim()
			intResult = ObjCompanyInfoBO.UpdatetblCompanyInfo()
			If intResult > 0 Then
				Page.RegisterStartupScript("SS", "<script> alert('Company Details Are Updated Succesfully'); </script>")
				txtCompanyName.Text = ""
				txtDescription.Text = ""
				txtAddress.Text = ""
			Else
				lblError.Text = "Error while Creation"
			End If
		Catch
			Throw
		End Try
	End Sub
	Protected Sub btnSave_Click(sender As Object, e As EventArgs)
		UpdatetblCompanyInfo()
	End Sub
End Class
