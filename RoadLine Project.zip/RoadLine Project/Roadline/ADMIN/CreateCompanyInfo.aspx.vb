Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class ADMIN_CreateCompanyInfo
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("ID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
		End If
	End Sub
	Protected Sub Button1_Click(sender As Object, e As EventArgs)
		Try
			Dim intResult As Integer = 0
			Dim ObjCompanyInfoBO As New CompanyInfoBO()
			ObjCompanyInfoBO.CompanyName = txtCompanyName.Text.Trim()
			ObjCompanyInfoBO.Description = txtDescription.Text.Trim()
			ObjCompanyInfoBO.Address = txtAddress.Text.Trim()
			intResult = ObjCompanyInfoBO.InsertIntoCompanyInfo()
			If intResult > 0 Then
				Page.RegisterStartupScript("SS", "<script> alert('Succesfully Created'); </script>")
				txtCompanyName.Text = ""
				txtDescription.Text = ""
				txtAddress.Text = ""
			Else
			End If
		Catch
			Throw
		End Try
	End Sub
	Protected Sub btnBack_Click(sender As Object, e As EventArgs)
		Response.Redirect("MaintainCompanyInfo.aspx")
	End Sub
End Class
