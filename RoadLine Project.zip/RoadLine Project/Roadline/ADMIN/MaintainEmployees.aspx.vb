Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class ADMIN_MaintainEmployees
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("ID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
			EmployeeDetails()
		End If
	End Sub
	Private Sub EmployeeDetails()
		Try
			Dim objEmployeeBO As New EmployeeBO()
			Dim ds As New DataSet()
			ds = objEmployeeBO.ShowEmployee()
			If ds IsNot Nothing Then
				If ds.Tables(0).Rows.Count > 0 Then
					dgEmployees.DataSource = ds
					dgEmployees.DataBind()
				End If
			Else
				dgEmployees.DataSource = Nothing
				dgEmployees.DataBind()
			End If
		Catch
			dgEmployees.DataSource = Nothing
			dgEmployees.DataBind()
		End Try
	End Sub
	Protected Sub lnkAdd_Click(sender As Object, e As EventArgs)
		Response.Redirect("CreateEmployee.aspx")
	End Sub
	Protected Sub lnkCheckAll_Click(sender As Object, e As EventArgs)
		lblError.Text = ""
		Dim i As Integer = 0
		While i < dgEmployees.Items.Count
			Dim chk As CheckBox = CType(dgEmployees.Items(i).FindControl("chkDel"), CheckBox)
			chk.Checked = True
			System.Math.Max(System.Threading.Interlocked.Increment(i),i - 1)
		End While
	End Sub
	Protected Sub lnkClearAll_Click(sender As Object, e As EventArgs)
		lblError.Text = ""
		Dim i As Integer = 0
		While i < dgEmployees.Items.Count
			Dim chk As CheckBox = CType(dgEmployees.Items(i).FindControl("chkDel"), CheckBox)
			chk.Checked = False
			System.Math.Max(System.Threading.Interlocked.Increment(i),i - 1)
		End While
	End Sub
	Protected Sub lnlDelete_Click(sender As Object, e As EventArgs)
		Try
			Dim Ids As [String] = ""
			Dim i As Int16 = 0
			While i < dgEmployees.Items.Count
				If (CType(dgEmployees.Items(i).FindControl("chkDel"), CheckBox)).Checked = True Then
					Ids += dgEmployees.DataKeys(i) + ","
				End If
                '	System.Math.Max(System.Threading.Interlocked.Increment(i),i - 1)
                i = i + 1
			End While
			If Ids <> "" Then
				Ids = Ids.TrimEnd(","C)
				Dim Result As [Boolean] = False
				Dim objEmployeeBO As New EmployeeBO()
				Result = objEmployeeBO.DeleteFromtblEmployees(Ids)
				If Result Then
					EmployeeDetails()
					lblError.Text = "Employee Details deleted successfully"
				Else
					lblError.Text = "Error in deletion"
				End If
			Else
				lblError.Text = "Select a record to delete"
			End If
		Catch
		End Try
	End Sub
	Protected Sub dgEmployees_ItemCommand(source As Object, e As DataGridCommandEventArgs)
		If e.CommandName = "Edit" Then
			Response.Redirect("EditEmployeeInfo.aspx?Id=" + dgEmployees.DataKeys(e.Item.ItemIndex))
		End If
	End Sub
End Class
