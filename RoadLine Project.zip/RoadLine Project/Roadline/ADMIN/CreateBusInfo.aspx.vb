Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class ADMIN_CreateBusInfo
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("ID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
		End If
	End Sub
	Protected Sub Button1_Click(sender As Object, e As EventArgs)
        Try
            Dim intResult As Integer = 0
            Dim ObjBusInfoBO As New BusInfoBO()
            ObjBusInfoBO.ServiceName = txtServiceName.Text.Trim()
            ObjBusInfoBO.ServiceNumber = txtServiceNumber.Text.Trim()
            ObjBusInfoBO.TravelName = txtTravelName.Text.Trim()
            ObjBusInfoBO.Fare = txtFare.Text.Trim()
            ObjBusInfoBO.NoOfSeatsAvailable = txtNoOfSeatsAvailable.Text.Trim()
            ObjBusInfoBO.StartTime = txtTime.Text.Trim()
            ObjBusInfoBO.DateOfJourney = Convert.ToDateTime(txtDateOfJourney.Text.Trim())

            If ddlBusType.SelectedIndex <> 0 Then
                ObjBusInfoBO.BusType = ddlBusType.SelectedItem.Text
            End If
            If ddlSource.SelectedIndex <> 0 Then
                ObjBusInfoBO.Source = ddlSource.SelectedItem.Text
            End If
            If ddlDestination.SelectedIndex <> 0 Then
                ObjBusInfoBO.Destination = ddlDestination.SelectedItem.Text
            End If
            intResult = ObjBusInfoBO.InsertIntoBusInfo()
            If intResult > 0 Then
                Page.RegisterStartupScript("SS", "<script> alert('Succesfully Provided The Bus Details'); </script>")
                txtServiceName.Text = ""
                txtServiceNumber.Text = ""
                txtTravelName.Text = ""
                txtFare.Text = ""
                txtNoOfSeatsAvailable.Text = ""
                ddlDestination.SelectedIndex = 0
                ddlSource.SelectedIndex = 0
                ddlBusType.SelectedIndex = 0
                txtTime.Text = ""
                txtDateOfJourney.Text = ""
            Else
            End If
        Catch
            Throw
        End Try
    End Sub
	Protected Sub btnBack_Click(sender As Object, e As EventArgs)
		Response.Redirect("MaintainBusInfo.aspx")
	End Sub
End Class
