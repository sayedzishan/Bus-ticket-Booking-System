Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class Users_Login
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Not Page.IsPostBack Then
			If Request.Cookies("mycookie") IsNot Nothing Then
				Dim cookie As HttpCookie = Request.Cookies.[Get]("mycookie")
				Dim UserName As String = cookie.Values("UserName").ToString()
				Dim Password As String = cookie.Values("Password").ToString()
				txtUserName.Text = UserName
				txtPassword.Attributes.Add("value", Password)
				chkSavePassword.Checked = True
			End If
		End If
	End Sub
	Protected Sub BtnSubmit_Click(sender As Object, e As EventArgs)
		CheckLogin()
	End Sub
	Private Sub CheckLogin()
		Try
			Dim ObjUsersBO As New UsersBO()
			ObjUsersBO.UserName = txtUserName.Text.Trim()
			ObjUsersBO.Password = txtPassword.Text.Trim()
			Dim ds As New DataSet()
			ds = ObjUsersBO.CheckLogin()
			If ds IsNot Nothing Then
				If ds.Tables(0).Rows.Count > 0 Then
					If Convert.ToChar(ds.Tables(0).Rows(0)("Status")) <> "I"C Then
						If chkSavePassword.Checked = True Then
							Dim myCookie As New HttpCookie("myCookie")
							Response.Cookies.Remove("myCookie")
							Response.Cookies.Add(myCookie)
							myCookie.Values.Add("UserName", txtUserName.Text.Trim().ToString())
							myCookie.Values.Add("Password", txtPassword.Text.Trim().ToString())
							myCookie.Expires = DateTime.Now.AddDays(1)
						End If
						Session("UserID") = ds.Tables(0).Rows(0)("UserID")
						Response.Redirect("MyProfile.aspx")
					Else
						lblError.Text = "Profile was in InActive Mode"
					End If
				Else
					lblError.Text = "Invalid Username or Password"
				End If
			Else
				lblError.Text = "Invalid Username or Password"
			End If
		Catch
		End Try
	End Sub
	Protected Sub BtnReset_Click(sender As Object, e As EventArgs)
	End Sub
End Class
