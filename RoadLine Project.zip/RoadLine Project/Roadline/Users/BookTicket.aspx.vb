Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Net.Mail
Public Partial Class Users_BookTicket
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("UserID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
			GetServiceNumbers()
		End If
	End Sub
	Protected Sub GetServiceNumbers()
		Dim objBookTicketBO As New BookTicketBO()
		Dim Dt As New DataSet()
		Dt = objBookTicketBO.GetServiceNumbers()
		ddlServiceNumber.DataSource = Dt
		ddlServiceNumber.DataTextField = "ServiceNumber"
		ddlServiceNumber.DataValueField = "ServiceNumber"
		ddlServiceNumber.DataBind()
	End Sub
	Protected Sub GetData()
		If ddlServiceNumber.SelectedIndex <> 0 Then
			Dim objBookTicketBO As New BookTicketBO()
			Dim GetDatads As New DataSet()
			objBookTicketBO.ServiceNumber = ddlServiceNumber.SelectedItem.Text
			Try
				GetDatads = objBookTicketBO.Record()
				txtTravelName.Text = GetDatads.Tables("tblBusInfo").Rows(0)("TravelName").ToString()
				txtCost.Text = GetDatads.Tables("tblBusInfo").Rows(0)("Fare").ToString()
				txtAvailableSeats.Text = GetDatads.Tables("tblBusInfo").Rows(0)("NoOfSeatsAvailable").ToString()
				txtStartTime.Text = GetDatads.Tables("tblBusInfo").Rows(0)("StartTime").ToString()
				txtJourneyDate.Text = GetDatads.Tables("tblBusInfo").Rows(0)("DateOfJourney").ToString()
				ddlBusType.Text = GetDatads.Tables("tblBusInfo").Rows(0)("BusType").ToString()
				ddlSource.Text = GetDatads.Tables("tblBusInfo").Rows(0)("Source").ToString()
				ddlDestination.Text = GetDatads.Tables("tblBusInfo").Rows(0)("Destination").ToString()
			Catch
				Throw
			Finally
				GetDatads.Dispose()
				objBookTicketBO = Nothing
			End Try
		End If
	End Sub
	Protected Sub ddlServiceNumber_SelectedIndexChanged(sender As Object, e As EventArgs)
		GetData()
	End Sub
	Private Sub InsertIntotblBookTicket()
		Dim intTicketId As Int64 = 0
		Try
			Dim ds As New DataSet()
			Dim objBookTicketBO As New BookTicketBO()
			objBookTicketBO.FullName = txtName.Text.Trim()
			objBookTicketBO.TravelName = txtTravelName.Text.Trim()
			objBookTicketBO.Fare = txtCost.Text.Trim()
			objBookTicketBO.AvailableSeats = txtAvailableSeats.Text.Trim()
			objBookTicketBO.JourneyDate = txtJourneyDate.Text.Trim()
			objBookTicketBO.StartTime = txtStartTime.Text.Trim()
			objBookTicketBO.Address = txtAddress.Text.Trim()
			objBookTicketBO.Gender = RadioButtonList1.SelectedValue
			objBookTicketBO.NoOfPassengers = txtPassengers.Text.Trim()
			objBookTicketBO.IDCardType = txtCardType.Text.Trim()
			objBookTicketBO.IDCardNumber = txtCardNumber.Text.Trim()
			objBookTicketBO.Email = txtEmail.Text.Trim()
			objBookTicketBO.IssuingAuthority = txtAuthority.Text.Trim()
			If ddlServiceNumber.SelectedIndex <> 0 Then
				objBookTicketBO.ServiceNumber = ddlServiceNumber.SelectedItem.Text
			End If
			If ddlSource.SelectedIndex <> 0 Then
				objBookTicketBO.Source = ddlSource.SelectedItem.Text
			End If
			If ddlDestination.SelectedIndex <> 0 Then
				objBookTicketBO.Destination = ddlDestination.SelectedItem.Text
			End If
			If ddlBusType.SelectedIndex <> 0 Then
				objBookTicketBO.BusType = ddlBusType.SelectedItem.Text
			End If
			If txtPhCountry.Text.Trim() <> "" AndAlso txtPhSTD.Text.Trim() <> "" AndAlso txtPhone.Text.Trim() <> "" Then
				objBookTicketBO.Phone = txtPhCountry.Text.Trim() + "~" + txtPhSTD.Text.Trim() + "~" + txtPhone.Text.Trim()
			End If
			If txtMobileCountry.Text.Trim() <> "" AndAlso txtMobile.Text.Trim() <> "" Then
				objBookTicketBO.Mobile = txtMobileCountry.Text.Trim() + "~" + txtMobile.Text.Trim()
			End If
			intTicketId = objBookTicketBO.InsertIntotblBookTicket()
			If intTicketId > 0 Then
				Wizard1.ActiveStepIndex = 1
				Label1.Text = intTicketId.ToString()
			Else
			End If
		Catch
			Throw
		End Try
	End Sub
	Protected Sub btnSave_Click(sender As Object, e As EventArgs)
		InsertIntotblBookTicket()
	End Sub
	Protected Sub btnFinish_Click1(sender As Object, e As EventArgs)
		Dim objBookTicketBO As New BookTicketBO()
		Dim TicketID As Int64 = Convert.ToInt64(Label1.Text)
		Dim Name As [String] = txtName.Text.Trim()
		Dim Email As [String] = txtEmail.Text.Trim()
		Dim ServiceNumber As [String] = ddlServiceNumber.SelectedItem.Text.Trim()
		Dim TravelName As [String] = txtTravelName.Text.Trim()
		Dim DateOfJourney As [String] = txtJourneyDate.Text.Trim()
		Dim StartTime As [String] = txtStartTime.Text.Trim()
		Dim Mobile As [String] = txtMobile.Text.Trim()
		SendMail(Name, Email, ServiceNumber, TravelName, DateOfJourney, StartTime, _
			Mobile, TicketID)
		Response.Redirect("MyProfile.aspx")
	End Sub
	Private Sub SendMail(Name As [String], Email As [String], ServiceNumber As [String], TravelName As [String], DateOfJourney As [String], StartTime As [String], _
		Mobile As [String], TicketID As Int64)
		Try
			Dim MailMsg As New MailMessage()
			MailMsg.From = New MailAddress("Obtrs@mail.com")
			MailMsg.[To].Add(Email)
			MailMsg.Subject = "Ticket Confirmation Details"
			MailMsg.IsBodyHtml = True
			MailMsg.Priority = MailPriority.Normal
			Dim Bodytext As [String] = ""
			Bodytext = "<table cellpadding='0' cellspacing='0' width='100%' style='font-family:Verdana; font-size:12px'>"
			Bodytext += "<tr><td>Hi <b>" + Name + "</b>,</td></tr><tr><td>&nbsp;</td></tr>"
			Bodytext += "<tr><td>Thank you for Booking Ticket with Online Bus Ticket Reservation System. </td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr>"
			Bodytext += "<tr><td><b>" + "<font color=""red"">Your Ticket Details </font>" + "</b></td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr>"
			Bodytext += "<tr><td>ServiceNumber:<b>" + ServiceNumber + "</b></td></tr>"
			Bodytext += "<tr><td>DateOfJourney:<b>" + DateOfJourney + "</b></td></tr>"
			Bodytext += "<tr><td>TravelName:<b>" + TravelName + "</b></td></tr>"
			Bodytext += "<tr><td>StartTime:<b>" + StartTime + "</b></td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr>"
			Bodytext += "<tr><td><b>" + "<font color=""red"">Your Current Contact Details Are: </font>" + "</b></td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr>"
			Bodytext += "<tr><td>Mobile: <b>" + Mobile + "</b></td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr><tr><td>Thanks & Regards,<br />OnlineBusTicketReservation Team</td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr></table>"
			MailMsg.Body = Bodytext
			Dim SC As New SmtpClient("localhost")
			SC.Send(MailMsg)
		Catch
			Throw
		End Try
	End Sub
	Protected Sub btnBack_Click1(sender As Object, e As EventArgs)
		If Request.QueryString("From") IsNot Nothing Then
			Response.Redirect("SearchForBus.aspx?From=" + Request.QueryString("From").ToString() + "&To=" + Request.QueryString("To").ToString() + "&No=" + Request.QueryString("No").ToString() + "&Date=" + Request.QueryString("Date").ToString())
		Else
			Response.Redirect("SearchForBus.aspx")
		End If
	End Sub
End Class
