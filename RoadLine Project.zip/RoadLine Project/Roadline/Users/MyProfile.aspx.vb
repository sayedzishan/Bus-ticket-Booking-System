Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class USERS_MyProfile
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("UserID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
			If Session("UserID") IsNot Nothing Then
				ShowUserDetails()
			End If
		End If
	End Sub
	Private Sub ShowUserDetails()
		Dim ObjUsersBO As New UsersBO()
		ObjUsersBO.UserID = Integer.Parse(Session("UserID").ToString())
		Dim DsGetDataById As New DataSet()
		DsGetDataById = ObjUsersBO.ShowUsersInfo()
		If DsGetDataById IsNot Nothing Then
			If DsGetDataById.Tables(0).Rows.Count > 0 Then
				If DsGetDataById.Tables(0).Rows(0)("UserName").ToString() <> "" Then
					lblUserName.Text = DsGetDataById.Tables(0).Rows(0)("UserName").ToString()
				Else
					lblUserName.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Email").ToString() <> "" Then
					lblEmail.Text = DsGetDataById.Tables(0).Rows(0)("Email").ToString()
				Else
					lblEmail.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Address").ToString() <> "" Then
					lblAddress.Text = DsGetDataById.Tables(0).Rows(0)("Address").ToString()
				Else
					lblAddress.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Country").ToString() <> "" Then
					ddlCountry.Text = DsGetDataById.Tables(0).Rows(0)("Country").ToString()
				Else
					ddlCountry.Text = " "
				End If
				If DsGetDataById.Tables(0).Rows(0)("City").ToString() <> "" Then
					ddlCity.Text = DsGetDataById.Tables(0).Rows(0)("City").ToString()
				Else
					ddlCity.Text = ""
				End If
				If DsGetDataById.Tables(0).Rows(0)("CreatedDate").ToString() <> "" Then
					lblCreatedDate.Text = DsGetDataById.Tables(0).Rows(0)("CreatedDate").ToString()
				Else
					lblCreatedDate.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Mobile").ToString() <> "" Then
					txtMobileCountry.Text = DsGetDataById.Tables(0).Rows(0)("Mobile").ToString().Replace("~"C, "-"C)
				Else
					txtMobileCountry.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Phone").ToString() <> "" Then
					txtPhCountry.Text = DsGetDataById.Tables(0).Rows(0)("Phone").ToString().Replace("~"C, "-"C)
				Else
					txtPhCountry.Text = "Not Mentioned"
				End If
			End If
		End If
	End Sub
	Protected Sub btnEdit_Click(sender As Object, e As EventArgs)
		Response.Redirect("EditProfile.aspx")
	End Sub
	Protected Sub btnBack_Click(sender As Object, e As EventArgs)
		Response.Redirect("Home.aspx")
	End Sub
End Class
