Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class Users_ChangePassword
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("UserID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
	End Sub
	Protected Sub btnChangePwd_Click(sender As Object, e As EventArgs)
		ChangePassword()
	End Sub
	Private Sub ChangePassword()
		Try
			Dim objUsersBO As New UsersBO()
			If Session("UserId").ToString() IsNot Nothing Then
				objUsersBO.UserID = Convert.ToInt64(Session("UserId"))
				Dim DsChangePassword As New DataSet()
				DsChangePassword = objUsersBO.ShowUserById()
				If DsChangePassword IsNot Nothing Then
					If txtOldPassword.Text = DsChangePassword.Tables(0).Rows(0)("Password").ToString() Then
						objUsersBO.Password = txtNewPwd.Text.Trim()
						Dim Result As Integer = 0
						Result = objUsersBO.ChangePassword()
						If Result > 0 Then
							Page.RegisterStartupScript("SS", "<script> alert('Password Changed Succesfully'); </script>")
							txtOldPassword.Text = ""
							txtNewPwd.Text = ""
							txtConfNewPwd.Text = ""
						Else
							lblErrMsg.Text = "Error in Updation"
						End If
					Else
						lblErrMsg.Text = "Invalid OldPassword"
					End If
				End If
			Else
				lblErrMsg.Text = "You have to login First For Changing The Password"
			End If
		Catch
			Throw
		End Try
	End Sub
	Protected Sub btnCancel_Click(sender As Object, e As EventArgs)
		Response.Redirect("MyProfile.aspx")
	End Sub
End Class
