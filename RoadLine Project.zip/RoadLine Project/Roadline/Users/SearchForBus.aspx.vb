Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class Users_SearchPage
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("UserID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not IsPostBack Then
			If Request.QueryString("From") IsNot Nothing Then
				getSearchDetails()
				tblSearch.Visible = True
			Else
				tblSearch.Visible = False
				lblError.Text = ""
			End If
		End If
	End Sub
	Private Sub getSearchDetails()
		Dim ObjBusInfoBO As New BusInfoBO()
		Dim SearchString As String = String.Empty
		SearchString = SearchString + "(Destination like '%" + Request.QueryString("To").ToString() + "%' and "
		If ddlDestination.Items.FindByText(Request.QueryString("To").ToString()) IsNot Nothing Then
			ddlDestination.Items.FindByText(Request.QueryString("To").ToString()).Selected = True
		End If
		SearchString += "Source like '%" + Request.QueryString("From").ToString() + "%' and "
		If ddlSource.Items.FindByText(Request.QueryString("From").ToString()) IsNot Nothing Then
			ddlSource.Items.FindByText(Request.QueryString("From").ToString()).Selected = True
		End If
		SearchString += "NoOfSeatsAvailable >=" + Request.QueryString("No").ToString() + " and "
		txtNoOfPassengers.Text = Request.QueryString("No").ToString()
		SearchString += "convert(varchar(20),DateOfJourney,101) ='" + Request.QueryString("Date").ToString() + "')"
		txtDateOfJourney.Text = Request.QueryString("Date").ToString()
		Dim ds As New DataSet()
		ds = ObjBusInfoBO.SearchDetails(SearchString)
		If ds IsNot Nothing AndAlso ds.Tables(0).Rows.Count > 0 Then
			tblSearch.Visible = True
			dgSearchResults.DataSource = ds
			dgSearchResults.DataBind()
			lblError.Text = ""
		Else
			lblError.Text = "Sorry There are no buses for your Search"
		End If
	End Sub
	Protected Sub btnCheck_Click(sender As Object, e As EventArgs)
		Dim ObjBusInfoBO As New BusInfoBO()
		Dim SearchString As String = String.Empty
		SearchString = SearchString + "(Destination like '%" + ddlDestination.SelectedItem.Text + "%' and "
		SearchString += "Source like '%" + ddlSource.SelectedItem.Text + "%' and "
		SearchString += "NoOfSeatsAvailable >=" + txtNoOfPassengers.Text.Trim() + " and "
		SearchString += "convert(varchar(20),DateOfJourney,101) ='" + txtDateOfJourney.Text.Trim() + "')"
		Dim ds As New DataSet()
		ds = ObjBusInfoBO.SearchDetails(SearchString)
		If ds IsNot Nothing AndAlso ds.Tables(0).Rows.Count > 0 Then
			tblSearch.Visible = True
			dgSearchResults.DataSource = ds
			dgSearchResults.DataBind()
			lblError.Text = ""
		Else
			lblError.Text = "Sorry There are no buses for your Search"
		End If
	End Sub
	Protected Sub btnBook_Click(sender As Object, e As EventArgs)
		Response.Redirect("BookTicket.aspx?From=" + ddlSource.SelectedItem.Text + "&To=" + ddlDestination.SelectedItem.Text + "&No=" + txtNoOfPassengers.Text.Trim() + "&Date=" + txtDateOfJourney.Text.Trim())
	End Sub
End Class
