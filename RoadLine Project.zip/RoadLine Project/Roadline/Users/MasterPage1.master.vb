Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class Users_MasterPage
	Inherits System.Web.UI.MasterPage
	Protected Sub Page_Load(sender As Object, e As EventArgs)
	End Sub
End Class
