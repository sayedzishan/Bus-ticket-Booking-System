Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Imports System.Net.Mail
Public Partial Class Users_MailaFriend
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("UserID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
	End Sub
	Protected Sub btnSend_Click(sender As Object, e As EventArgs)
		Dim ObjMailaFriendBO As New MailaFriendBO()
		Dim StandardContent As [String] = txtStandardContent.Text
		Dim Comment As [String] = txtDetails.Text.Trim()
		Dim YourEmailID As [String] = txtYourEmailID.Text.Trim()
		Dim FriendsEmailID1 As [String] = txtFriendsEmailID1.Text.Trim()
		SendMail(StandardContent, Comment, YourEmailID, FriendsEmailID1)
		Page.RegisterStartupScript("SS", "<script> alert('Mail Was Sent Successfully'); </script>")
	End Sub
	Private Sub SendMail(StandardContent As [String], Comment As [String], YourEmailID As [String], FriendsEmailID1 As [String])
		Try
			Dim MailMsg As New MailMessage()
			MailMsg.From = New MailAddress("Obtrs@mail.com")
			MailMsg.[To].Add(YourEmailID)
			MailMsg.Subject = "See This it is very good"
			MailMsg.IsBodyHtml = True
			MailMsg.Priority = MailPriority.Normal
			Dim Bodytext As [String] = ""
			Bodytext = "<table cellpadding='0' cellspacing='0' width='100%' style='font-family:Verdana; font-size:12px'>"
			Bodytext += "<tr><td>&nbsp;</td></tr>"
			Bodytext += "<tr><td><b>" + "<font color=""red"">About This Website </font>" + "</b></td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr>"
			Bodytext += "<tr><td><b>" + StandardContent + "</b></td></tr>"
			Bodytext += "<tr><td><b>" + Comment + "</b></td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr><tr><td>&nbsp;</td></tr><tr><td>Thanks & Regards,<br />OnlineBusTicketReservation Team</td></tr>"
			Bodytext += "<tr><td>&nbsp;</td></tr></table>"
			MailMsg.Body = Bodytext
			Dim SC As New SmtpClient("localhost")
			SC.Send(MailMsg)
		Catch
			Throw
		End Try
	End Sub
	Protected Sub btnBack_Click1(sender As Object, e As EventArgs)
		Response.Redirect("Home.aspx")
	End Sub
End Class
