Imports System
Imports System.Data
Imports System.Configuration
Imports System.Collections
Imports System.Web
Imports System.Web.Security
Imports System.Web.UI
Imports System.Web.UI.WebControls
Imports System.Web.UI.WebControls.WebParts
Imports System.Web.UI.HtmlControls
Public Partial Class Employees_EditProfile
	Inherits System.Web.UI.Page
	Protected Sub Page_Load(sender As Object, e As EventArgs)
		If Session("UserID") Is Nothing Then
			Response.Redirect("~/Login.aspx")
		End If
		If Not Page.IsPostBack Then
			If Session("UserID") IsNot Nothing Then
				ShowUsersInfo()
			End If
		End If
	End Sub
	Private Sub ShowUsersInfo()
		Dim ObjUsersBO As New UsersBO()
		ObjUsersBO.UserID = Integer.Parse(Session("UserID").ToString())
		Dim DsGetDataById As New DataSet()
		DsGetDataById = ObjUsersBO.ShowUsersInfo()
		If DsGetDataById IsNot Nothing Then
			If DsGetDataById.Tables(0).Rows.Count > 0 Then
				If DsGetDataById.Tables(0).Rows(0)("UserName").ToString() <> "" Then
					lblUserName.Text = DsGetDataById.Tables(0).Rows(0)("UserName").ToString()
				Else
					lblUserName.Text = "Not Mentioned"
				End If
				If DsGetDataById.Tables(0).Rows(0)("Address").ToString() <> "" Then
					txtAddress.Text = DsGetDataById.Tables(0).Rows(0)("Address").ToString()
				Else
					txtAddress.Text = " "
				End If
				If DsGetDataById.Tables(0).Rows(0)("Country").ToString() <> "" Then
					ddlCountry.ClearSelection()
					ddlCountry.Items.FindByText(DsGetDataById.Tables(0).Rows(0)("Country").ToString()).Selected = True
				Else
					ddlCountry.Text = " "
				End If
				If DsGetDataById.Tables(0).Rows(0)("City").ToString() <> "" Then
					txtCity.Text = DsGetDataById.Tables(0).Rows(0)("City").ToString()
				Else
					txtCity.Text = " "
				End If
				If DsGetDataById.Tables(0).Rows(0)("Mobile").ToString() <> "" Then
					Dim strMobile As String() = (DsGetDataById.Tables(0).Rows(0)("Mobile").ToString()).Split("~"C)
					txtMobileCountry.Text = strMobile(0).ToString()
					txtMobile.Text = strMobile(1).ToString()
				Else
					txtMobileCountry.Text = " "
				End If
				If DsGetDataById.Tables(0).Rows(0)("Phone").ToString() <> "" Then
					Dim strPh As String() = (DsGetDataById.Tables(0).Rows(0)("Phone").ToString()).Split("~"C)
					txtPhCountry.Text = strPh(0).ToString()
					txtPhSTD.Text = strPh(1).ToString()
					txtPhone.Text = strPh(2).ToString()
				End If
				If DsGetDataById.Tables(0).Rows(0)("Email").ToString() <> "" Then
					txtEmail.Text = DsGetDataById.Tables(0).Rows(0)("Email").ToString()
				Else
					txtEmail.Text = " "
				End If
			End If
		End If
	End Sub
	Private Sub UpdatetblUsers()
		Try
			If ValidateFields() Then
				Dim intResult As Integer = 0
				Dim ObjUsersBO As New UsersBO()
				ObjUsersBO.UserID = Integer.Parse(Session("UserID").ToString())
				ObjUsersBO.Address = txtAddress.Text.Trim()
				ObjUsersBO.City = txtCity.Text.Trim()
				ObjUsersBO.Email = txtEmail.Text.Trim()
				If txtPhCountry.Text.Trim() <> "" AndAlso txtPhSTD.Text.Trim() <> "" AndAlso txtPhone.Text.Trim() <> "" Then
					ObjUsersBO.Phone = txtPhCountry.Text.Trim() + "~" + txtPhSTD.Text.Trim() + "~" + txtPhone.Text.Trim()
				End If
				If txtMobileCountry.Text.Trim() <> "" AndAlso txtMobile.Text.Trim() <> "" Then
					ObjUsersBO.Mobile = txtMobileCountry.Text.Trim() + "~" + txtMobile.Text.Trim()
				End If
				If ddlCountry.SelectedIndex <> 0 Then
					ObjUsersBO.Country = ddlCountry.SelectedItem.Text
				End If
				intResult = ObjUsersBO.UpdatetblUsers()
				If intResult > 0 Then
					Response.Redirect("MyProfile.aspx")
				Else
					lblError.Text = "Error while Creation"
				End If
			End If
		Catch
			Throw
		End Try
	End Sub
	Private Function ValidateFields() As Boolean
		Try
			If txtEmail.Text.Trim() = "" Then
				lblError.Text = "Enter Email ID"
				Return False
			End If
			If txtAddress.Text.Trim() = "" Then
				lblError.Text = "Enter Address"
				Return False
			End If
			If ddlCountry.SelectedIndex = 0 Then
				lblError.Text = "Select Country"
				Return False
			End If
			If txtCity.Text.Trim() = "" Then
				lblError.Text = "Enter City"
				Return False
			End If
			If txtMobileCountry.Text.Trim() = "" Then
				lblError.Text = "Enter Mobile Country Code"
				Return False
			End If
			If txtMobile.Text.Trim() = "" Then
				lblError.Text = "Enter Mobile Number"
				Return False
			End If
			Return True
		Catch
			Return False
		End Try
	End Function
	Protected Sub btnSave_Click(sender As Object, e As EventArgs)
		UpdatetblUsers()
	End Sub
	Protected Sub btnReset_Click(sender As Object, e As EventArgs)
		Response.Redirect("MyProfile.aspx")
	End Sub
End Class
